// Docker'siz ishga tushirish (pm2). Avval: cd server && npm ci && npm run build && npx prisma db push
// Frontend: cd frontend && npm ci && npm run build  (dist/ papkasini Nginx beradi)
module.exports = {
  apps: [
    {
      name: 'robux-api',
      cwd: './server',
      script: 'dist/index.js',
      env_file: '../.env',
      env: { NODE_ENV: 'production' },
      max_memory_restart: '400M',
      autorestart: true,
    },
  ],
};
