import { config } from './config';
import { prisma } from './db';
import { parseRef } from './auth';
import { getSettings } from './settings';
import { tgCall } from './telegramApi';
import { missingChannels } from './subscription';

/**
 * Oddiy long-polling bot:
 *  - /start ref_<ID> ni qabul qiladi, taklif qilganni eslab qoladi;
 *  - majburiy obuna kanallari bo'lsa, avval o'shalarga obuna bo'lishni so'raydi;
 *  - obuna bo'lgach Mini App ni ochish tugmasini beradi;
 *  - /admin: faqat ADMIN_IDS uchun admin panel tugmasi.
 */
export async function startBot() {
  await tgCall('deleteWebhook', { drop_pending_updates: false });
  let offset = 0;
  console.log('[bot] polling boshlandi');

  const loop = async () => {
    for (;;) {
      try {
        const r = await fetch(`https://api.telegram.org/bot${config.botToken}/getUpdates`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ offset, timeout: 30, allowed_updates: ['message', 'callback_query'] }),
        });
        const j: any = await r.json();
        if (!j.ok) throw new Error(JSON.stringify(j));
        for (const upd of j.result as any[]) {
          offset = upd.update_id + 1;
          await handle(upd).catch((e) => console.error('[bot] handle', e));
        }
      } catch (e) {
        console.error('[bot] poll xatosi', e);
        await new Promise((r) => setTimeout(r, 3000));
      }
    }
  };
  void loop();
}

async function sendOpen(chatId: number | string) {
  await tgCall('sendMessage', {
    chat_id: chatId,
    text: '🎮 Rzon Robux ga xush kelibsiz!\nTugmani bosib ilovani oching, tap qiling va vazifalarni bajaring.',
    reply_markup: config.webAppUrl
      ? { inline_keyboard: [[{ text: '🚀 Ochish', web_app: { url: config.webAppUrl } }]] }
      : undefined,
  });
}

async function sendGate(chatId: number | string, tgId: string): Promise<boolean> {
  const missing = await missingChannels(tgId);
  if (missing.length === 0) return false;
  await tgCall('sendMessage', {
    chat_id: chatId,
    text: "📢 Ilovadan foydalanish uchun avval quyidagi kanallarga obuna bo'ling, so'ng \"✅ Tekshirish\" tugmasini bosing:",
    reply_markup: {
      inline_keyboard: [
        ...missing.map((c) => [{ text: `➕ ${c.title}`, url: c.url }]),
        [{ text: '✅ Tekshirish', callback_data: 'sub_check' }],
      ],
    },
  });
  return true;
}

async function handle(upd: any) {
  // "✅ Tekshirish" tugmasi
  if (upd.callback_query) {
    const q = upd.callback_query;
    if (q.data !== 'sub_check' || !q.message) return;
    const missing = await missingChannels(String(q.from.id));
    if (missing.length > 0) {
      await tgCall('answerCallbackQuery', {
        callback_query_id: q.id,
        text: `Hali obuna bo'lmagansiz: ${missing.map((c) => c.title).join(', ')}`,
        show_alert: true,
      });
      return;
    }
    await tgCall('answerCallbackQuery', { callback_query_id: q.id, text: 'Rahmat! ✅' });
    await sendOpen(q.message.chat.id);
    return;
  }

  const msg = upd.message;
  if (!msg?.text || !msg.from || msg.chat?.type !== 'private') return;

  if (msg.text.startsWith('/admin')) {
    // admin panelga faqat ADMIN_IDS dagi Telegram ID egasi kira oladi
    if (config.adminIds.includes(String(msg.from.id)) && config.webAppUrl) {
      await tgCall('sendMessage', {
        chat_id: msg.chat.id,
        text: '🔐 Admin panel',
        reply_markup: { inline_keyboard: [[{ text: 'Admin panelni ochish', web_app: { url: `${config.webAppUrl}/admin` } }]] },
      });
    }
    return;
  }
  if (!msg.text.startsWith('/start')) return;

  const tgId = String(msg.from.id);
  const refTg = parseRef(msg.text.split(' ')[1]);

  const exists = await prisma.user.findUnique({ where: { telegramId: tgId } });
  if (!exists) {
    const inviter = refTg && refTg !== tgId ? await prisma.user.findUnique({ where: { telegramId: refTg } }) : null;
    const s = await getSettings();
    try {
      await prisma.user.create({
        data: {
          telegramId: tgId,
          firstName: msg.from.first_name || 'User',
          username: msg.from.username || null,
          energy: s.maxEnergy,
          invitedById: inviter?.id ?? null,
        },
      });
    } catch {
      /* parallel yaratilgan bo'lishi mumkin */
    }
  }

  // majburiy obuna bo'lsa, avval o'sha so'raladi; bo'lmasa to'g'ridan-to'g'ri ilova
  if (await sendGate(msg.chat.id, tgId)) return;
  await sendOpen(msg.chat.id);
}
