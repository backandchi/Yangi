import { config } from './config';
import { prisma } from './db';
import { parseRef } from './auth';
import { getSettings } from './settings';
import { tgCall } from './telegramApi';

/**
 * Oddiy long-polling bot: /start ref_<ID> ni qabul qiladi, taklif qilganni eslab qoladi
 * va "Ochish" tugmasini yuboradi. Taklif mukofoti ilova birinchi marta ochilganda beriladi.
 */
export async function startBot() {
  await tgCall('deleteWebhook', { drop_pending_updates: false });
  let offset = 0;
  console.log('[bot] polling boshlandi');

  const loop = async () => {
    for (;;) {
      try {
        const r = await fetch(`https://api.telegram.org/bot${config.botToken}/getUpdates`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ offset, timeout: 30, allowed_updates: ['message'] }),
        });
        const j: any = await r.json();
        if (!j.ok) throw new Error(JSON.stringify(j));
        for (const upd of j.result as any[]) {
          offset = upd.update_id + 1;
          await handle(upd).catch((e) => console.error('[bot] handle', e));
        }
      } catch (e) {
        console.error('[bot] poll xatosi', e);
        await new Promise((r) => setTimeout(r, 3000));
      }
    }
  };
  void loop();
}

async function handle(upd: any) {
  const msg = upd.message;
  if (!msg?.text || !msg.from || msg.chat?.type !== 'private') return;
  if (!msg.text.startsWith('/start')) return;

  const tgId = String(msg.from.id);
  const param = msg.text.split(' ')[1];
  const refTg = parseRef(param);

  const exists = await prisma.user.findUnique({ where: { telegramId: tgId } });
  if (!exists) {
    const inviter = refTg && refTg !== tgId ? await prisma.user.findUnique({ where: { telegramId: refTg } }) : null;
    const s = await getSettings();
    await prisma.user.create({
      data: {
        telegramId: tgId,
        firstName: msg.from.first_name || 'User',
        username: msg.from.username || null,
        energy: s.maxEnergy,
        invitedById: inviter?.id ?? null,
      },
    });
  }

  await tgCall('sendMessage', {
    chat_id: msg.chat.id,
    text: '🎮 Robux Earn Hub ga xush kelibsiz!\nTugmani bosib ilovani oching, tap qiling va vazifalarni bajaring.',
    reply_markup: config.webAppUrl
      ? { inline_keyboard: [[{ text: '🚀 Ochish', web_app: { url: config.webAppUrl } }]] }
      : undefined,
  });
}
