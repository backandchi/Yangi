import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { User } from '@prisma/client';
import { config } from './config';
import { prisma } from './db';
import { getSettings } from './settings';
import { verifyInitData } from './telegramAuth';
import { sendText } from './telegramApi';
import { missingChannels } from './subscription';

declare module 'express-serve-static-core' {
  interface Request {
    user?: User;
    startParam?: string | null;
  }
}

export function parseRef(startParam?: string | null): string | null {
  if (!startParam) return null;
  const m = /^ref_(\d{1,20})$/.exec(startParam);
  return m ? m[1] : null;
}

/** Haqiqiy mijoz IP manzili (Railway/Nginx ortida X-Real-IP, aks holda req.ip). */
export function getIp(req: Request): string | null {
  const xri = req.headers['x-real-ip'];
  const v = (Array.isArray(xri) ? xri[0] : xri) || req.ip || '';
  const ip = v.split(',')[0].trim().replace(/^::ffff:/, '');
  return ip || null;
}

/**
 * Yangi do'st ilovani birinchi ochganda:
 *  - IP tekshiruvi o'tsa: ikkala tomonga mukofot;
 *  - bir IP/qurilmadan takroriy referal bo'lsa: bonus berilmaydi, referal qizil belgi bilan qoladi
 *    va taklif qilgandan jarima ushlanadi. Taklif qilganga Telegram orqali xabar yuboriladi.
 */
export async function applyWelcome(userId: number, ip: string | null): Promise<void> {
  const s = await getSettings();
  type Outcome = { kind: 'ok' | 'fraud'; inviterTg: string; name: string; amount: number } | null;

  const outcome: Outcome = await prisma.$transaction(async (tx) => {
    const me = await tx.user.findUnique({ where: { id: userId } });
    if (!me || me.welcomed) return null;

    // taklif qilgan odam yo'q
    if (!me.invitedById) {
      await tx.user.updateMany({ where: { id: userId, welcomed: false }, data: { welcomed: true } });
      return null;
    }

    const inviter = await tx.user.findUnique({ where: { id: me.invitedById } });
    let fraud = false;
    if (s.ipCheckEnabled && ip) {
      if (inviter?.ip && inviter.ip === ip) fraud = true; // o'zi o'zini taklif qilgan
      else {
        // shu IP dan allaqachon mukofotli referal kirgan
        const dup = await tx.user.count({
          where: { ip, invitedById: { not: null }, welcomed: true, fraud: false, id: { not: me.id } },
        });
        if (dup > 0) fraud = true;
      }
    }

    if (fraud && inviter) {
      const r = await tx.user.updateMany({
        where: { id: userId, welcomed: false },
        data: { welcomed: true, fraud: true },
      });
      if (r.count !== 1) return null;
      const newBalance = Math.max(0, inviter.balance - s.fraudPenalty);
      const taken = inviter.balance - newBalance;
      await tx.user.update({ where: { id: inviter.id }, data: { balance: newBalance } });
      await tx.fraudEvent.create({ data: { inviterId: inviter.id, inviteeId: me.id, ip, penalty: taken } });
      return { kind: 'fraud', inviterTg: inviter.telegramId, name: me.firstName, amount: taken };
    }

    const r = await tx.user.updateMany({
      where: { id: userId, welcomed: false },
      data: { welcomed: true, balance: { increment: s.referredReward }, totalEarned: { increment: s.referredReward } },
    });
    if (r.count === 1 && inviter) {
      await tx.user.update({
        where: { id: inviter.id },
        data: { balance: { increment: s.referralReward }, totalEarned: { increment: s.referralReward } },
      });
      return { kind: 'ok', inviterTg: inviter.telegramId, name: me.firstName, amount: s.referralReward };
    }
    return null;
  });

  // taklif qilganga xabar (xato bo'lsa e'tiborsiz)
  if (outcome) {
    const text =
      outcome.kind === 'fraud'
        ? `⚠️ ${outcome.name} sizning qurilmangiz/IP manzilingizdan kirdi. Bitta qurilmadan foydalanilgani uchun bonus berilmadi va ${outcome.amount} Robux ushlab qolindi.`
        : `🎉 ${outcome.name} sizning havolangiz orqali qo'shildi! +${outcome.amount} Robux.`;
    void sendText(outcome.inviterTg, text).catch(() => undefined);
  }
}

/** Har bir foydalanuvchi so'rovida initData ni serverda tekshiradi. */
export async function requireUser(req: Request, res: Response, next: NextFunction) {
  try {
    const header = req.headers.authorization || '';
    let tgId: string;
    let firstName: string;
    let username: string | null = null;
    let startParam: string | null = null;
    const ip = getIp(req);

    if (header.startsWith('tma ')) {
      const v = verifyInitData(header.slice(4), config.botToken);
      if (!v) return res.status(401).json({ error: 'Telegram autentifikatsiyasi muvaffaqiyatsiz' });
      tgId = String(v.user.id);
      firstName = v.user.first_name || 'User';
      username = v.user.username || null;
      startParam = v.startParam;
    } else if (config.devAuth && header.startsWith('dev ')) {
      const [id, name] = header.slice(4).split(':');
      tgId = String(id || '1');
      firstName = name || 'DevUser';
    } else {
      return res.status(401).json({ error: 'Avtorizatsiya talab qilinadi' });
    }

    let user = await prisma.user.findUnique({ where: { telegramId: tgId } });
    if (!user) {
      const s = await getSettings();
      const refTg = parseRef(startParam);
      const inviter = refTg && refTg !== tgId ? await prisma.user.findUnique({ where: { telegramId: refTg } }) : null;
      try {
        user = await prisma.user.create({
          data: {
            telegramId: tgId,
            firstName,
            username,
            energy: s.maxEnergy,
            ip,
            invitedById: inviter?.id ?? null,
          },
        });
      } catch {
        // parallel so'rovlar bir vaqtda yaratishga urinsa
        user = await prisma.user.findUnique({ where: { telegramId: tgId } });
      }
    }
    if (!user) return res.status(500).json({ error: 'Foydalanuvchi yaratilmadi' });
    if (user.banned) return res.status(403).json({ error: 'Siz bloklangansiz' });

    // bot orqali yaratilgan foydalanuvchida IP yo'q — birinchi kirishda yozamiz
    if (!user.ip && ip) {
      user = await prisma.user.update({ where: { id: user.id }, data: { ip } });
    }

    // majburiy obuna: kanallarga obuna bo'lmaguncha ilova ishlamaydi (referal mukofoti ham berilmaydi)
    const missing = await missingChannels(user.telegramId);
    if (missing.length > 0) {
      return res.status(403).json({
        error: "Avval quyidagi kanallarga obuna bo'ling",
        code: 'SUBSCRIBE_REQUIRED',
        channels: missing.map((c) => ({ title: c.title, url: c.url })),
      });
    }

    if (!user.welcomed) {
      await applyWelcome(user.id, ip);
      user = (await prisma.user.findUnique({ where: { id: user.id } })) || user;
    }
    if (header.startsWith('tma ') && (user.firstName !== firstName || user.username !== username)) {
      user = await prisma.user.update({ where: { id: user.id }, data: { firstName, username } });
    }

    req.user = user;
    req.startParam = startParam;
    next();
  } catch (e) {
    console.error('[requireUser]', e);
    res.status(500).json({ error: 'Server xatosi' });
  }
}

export function signAdminToken(sub: string): string {
  return jwt.sign({ role: 'admin', sub }, config.jwtSecret, { expiresIn: '12h' });
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return res.status(401).json({ error: 'Admin token kerak' });
  try {
    const payload = jwt.verify(header.slice(7), config.jwtSecret) as { role?: string };
    if (payload.role !== 'admin') return res.status(403).json({ error: "Ruxsat yo'q" });
    next();
  } catch {
    res.status(401).json({ error: 'Token yaroqsiz yoki muddati tugagan' });
  }
}
