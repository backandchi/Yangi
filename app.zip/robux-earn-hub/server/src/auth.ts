import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { User } from '@prisma/client';
import { config } from './config';
import { prisma } from './db';
import { getSettings } from './settings';
import { verifyInitData } from './telegramAuth';

declare module 'express-serve-static-core' {
  interface Request {
    user?: User;
    startParam?: string | null;
  }
}

export function parseRef(startParam?: string | null): string | null {
  if (!startParam) return null;
  const m = /^ref_(\d{1,20})$/.exec(startParam);
  return m ? m[1] : null;
}

/** Yangi do'st kirganda ikkala tomonga mukofot (faqat bir marta). */
export async function applyWelcome(userId: number): Promise<void> {
  const s = await getSettings();
  await prisma.$transaction(async (tx) => {
    const me = await tx.user.findUnique({ where: { id: userId } });
    if (!me || me.welcomed) return;
    const reward = me.invitedById ? s.referredReward : 0;
    const r = await tx.user.updateMany({
      where: { id: userId, welcomed: false },
      data: { welcomed: true, balance: { increment: reward }, totalEarned: { increment: reward } },
    });
    if (r.count === 1 && me.invitedById) {
      await tx.user.update({
        where: { id: me.invitedById },
        data: { balance: { increment: s.referralReward }, totalEarned: { increment: s.referralReward } },
      });
    }
  });
}

/** Har bir foydalanuvchi so'rovida initData ni serverda tekshiradi. */
export async function requireUser(req: Request, res: Response, next: NextFunction) {
  try {
    const header = req.headers.authorization || '';
    let tgId: string;
    let firstName: string;
    let username: string | null = null;
    let startParam: string | null = null;

    if (header.startsWith('tma ')) {
      const v = verifyInitData(header.slice(4), config.botToken);
      if (!v) return res.status(401).json({ error: 'Telegram autentifikatsiyasi muvaffaqiyatsiz' });
      tgId = String(v.user.id);
      firstName = v.user.first_name || 'User';
      username = v.user.username || null;
      startParam = v.startParam;
    } else if (config.devAuth && header.startsWith('dev ')) {
      const [id, name] = header.slice(4).split(':');
      tgId = String(id || '1');
      firstName = name || 'DevUser';
    } else {
      return res.status(401).json({ error: 'Avtorizatsiya talab qilinadi' });
    }

    let user = await prisma.user.findUnique({ where: { telegramId: tgId } });
    if (!user) {
      const s = await getSettings();
      const refTg = parseRef(startParam);
      const inviter = refTg && refTg !== tgId ? await prisma.user.findUnique({ where: { telegramId: refTg } }) : null;
      try {
        user = await prisma.user.create({
          data: {
            telegramId: tgId,
            firstName,
            username,
            energy: s.maxEnergy,
            invitedById: inviter?.id ?? null,
          },
        });
      } catch {
        // parallel so'rovlar bir vaqtda yaratishga urinsa
        user = await prisma.user.findUnique({ where: { telegramId: tgId } });
      }
    }
    if (!user) return res.status(500).json({ error: 'Foydalanuvchi yaratilmadi' });
    if (user.banned) return res.status(403).json({ error: 'Siz bloklangansiz' });

    if (!user.welcomed) {
      await applyWelcome(user.id);
      user = (await prisma.user.findUnique({ where: { id: user.id } })) || user;
    }
    if (user.firstName !== firstName || user.username !== username) {
      if (header.startsWith('tma ')) {
        user = await prisma.user.update({ where: { id: user.id }, data: { firstName, username } });
      }
    }

    req.user = user;
    req.startParam = startParam;
    next();
  } catch (e) {
    console.error('[requireUser]', e);
    res.status(500).json({ error: 'Server xatosi' });
  }
}

export function signAdminToken(sub: string): string {
  return jwt.sign({ role: 'admin', sub }, config.jwtSecret, { expiresIn: '12h' });
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return res.status(401).json({ error: 'Admin token kerak' });
  try {
    const payload = jwt.verify(header.slice(7), config.jwtSecret) as { role?: string };
    if (payload.role !== 'admin') return res.status(403).json({ error: 'Ruxsat yo\'q' });
    next();
  } catch {
    res.status(401).json({ error: 'Token yaroqsiz yoki muddati tugagan' });
  }
}
