import { Settings } from '@prisma/client';
import { prisma } from './db';

let cache: { value: Settings; at: number } | null = null;

export async function getSettings(): Promise<Settings> {
  if (cache && Date.now() - cache.at < 5000) return cache.value;
  const value = await prisma.settings.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } });
  cache = { value, at: Date.now() };
  return value;
}

export function invalidateSettings() {
  cache = null;
}
