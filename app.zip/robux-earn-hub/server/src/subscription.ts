import { RequiredChannel } from '@prisma/client';
import { prisma } from './db';
import { memberState } from './telegramApi';

let chCache: { v: RequiredChannel[]; at: number } | null = null;
const okUntil = new Map<string, number>(); // telegramId -> obuna tasdiqlangan vaqt (5 daqiqa)

export function invalidateChannels() {
  chCache = null;
  okUntil.clear();
}

export async function getRequiredChannels(): Promise<RequiredChannel[]> {
  if (chCache && Date.now() - chCache.at < 10_000) return chCache.v;
  const v = await prisma.requiredChannel.findMany({ where: { active: true }, orderBy: { id: 'asc' } });
  chCache = { v, at: Date.now() };
  return v;
}

/** Foydalanuvchi hali obuna bo'lmagan majburiy kanallar ro'yxati. */
export async function missingChannels(telegramId: string): Promise<RequiredChannel[]> {
  const chans = await getRequiredChannels();
  if (chans.length === 0) return [];
  const exp = okUntil.get(telegramId);
  if (exp && exp > Date.now()) return [];

  const missing: RequiredChannel[] = [];
  for (const c of chans) {
    const st = await memberState(c.chatId, telegramId);
    if (st === 'no') missing.push(c);
    if (st === 'error') console.warn(`[subscription] ${c.chatId} tekshirib bo'lmadi (bot kanalda admin bo'lishi kerak)`);
  }
  if (missing.length === 0) {
    if (okUntil.size > 50_000) okUntil.clear();
    okUntil.set(telegramId, Date.now() + 5 * 60_000);
  }
  return missing;
}
