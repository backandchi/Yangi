import { config } from './config';

export async function tgCall<T = any>(method: string, body: Record<string, unknown> = {}): Promise<T | null> {
  try {
    const r = await fetch(`https://api.telegram.org/bot${config.botToken}/${method}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const j: any = await r.json();
    return j.ok ? (j.result as T) : null;
  } catch (e) {
    console.error('[telegram]', method, e);
    return null;
  }
}

/** Foydalanuvchi kanal/guruh a'zosimi? (bot kanalda admin bo'lishi shart) */
export async function isChatMember(chatId: string, telegramId: string): Promise<boolean> {
  const r = await tgCall<{ status: string }>('getChatMember', { chat_id: chatId, user_id: Number(telegramId) });
  if (!r) return false;
  return ['member', 'administrator', 'creator'].includes(r.status);
}
