import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { config } from './config';
import { prisma } from './db';
import { getSettings } from './settings';
import { startBot } from './bot';
import { userRouter } from './routes/user';
import { adminRouter } from './routes/admin';

async function main() {
  await prisma.$connect();
  await getSettings(); // standart sozlamalar qatorini yaratadi

  const app = express();
  app.set('trust proxy', 1); // Nginx ortida
  app.use(helmet());
  if (config.corsOrigin) app.use(cors({ origin: config.corsOrigin.split(','), credentials: false }));
  app.use(express.json({ limit: '100kb' }));
  app.use(rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: true, legacyHeaders: false }));

  app.get('/api/health', (_req, res) => res.json({ ok: true }));
  app.use('/api/admin', adminRouter);
  app.use('/api', userRouter);

  app.use((_req, res) => res.status(404).json({ error: 'Topilmadi' }));

  app.listen(config.port, () => console.log(`[server] port ${config.port}`));
  if (process.env.DISABLE_BOT !== 'true') void startBot();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
