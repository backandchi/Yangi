import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { config } from '../config';
import { prisma } from '../db';
import { requireAdmin, signAdminToken } from '../auth';
import { getSettings, invalidateSettings } from '../settings';
import { verifyInitData } from '../telegramAuth';
import { invalidateChannels } from '../subscription';

export const adminRouter = Router();

const loginLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 10, standardHeaders: true, legacyHeaders: false });

/* ---- Login: faqat ADMIN_IDS dagi Telegram ID (initData tekshiriladi) ---- */
adminRouter.post('/login-telegram', loginLimiter, (req, res) => {
  const p = z.object({ initData: z.string().max(4000) }).safeParse(req.body);
  const v = p.success ? verifyInitData(p.data.initData, config.botToken, 6 * 3600) : null;
  if (!v || !config.adminIds.includes(String(v.user.id))) {
    return res.status(403).json({ error: 'Siz admin emassiz' });
  }
  res.json({ token: signAdminToken(`tg:${v.user.id}`) });
});

adminRouter.use(requireAdmin);

/* ---- Statistika ---- */
adminRouter.get('/stats', async (_req, res) => {
  const startOfDay = new Date();
  startOfDay.setUTCHours(0, 0, 0, 0);
  const [totalUsers, activeToday, newToday, banned, sums, pendingW, paidW, fraudCount] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { lastSeenAt: { gte: startOfDay } } }),
    prisma.user.count({ where: { createdAt: { gte: startOfDay } } }),
    prisma.user.count({ where: { banned: true } }),
    prisma.user.aggregate({ _sum: { totalEarned: true, balance: true } }),
    prisma.withdrawal.count({ where: { status: 'PENDING' } }),
    prisma.withdrawal.aggregate({ where: { status: 'PAID' }, _sum: { amount: true } }),
    prisma.fraudEvent.count(),
  ]);
  res.json({
    totalUsers,
    activeToday,
    newToday,
    banned,
    totalEarned: sums._sum.totalEarned ?? 0,
    totalBalance: sums._sum.balance ?? 0,
    pendingWithdrawals: pendingW,
    totalWithdrawn: paidW._sum.amount ?? 0,
    fraudBlocked: fraudCount,
  });
});

/* ---- Iqtisodiyot ---- */
const settingsSchema = z.object({
  pointsPerTap: z.number().min(0).max(1_000_000),
  globalMultiplier: z.number().min(0).max(1000),
  dailyLimit: z.number().min(0).max(1_000_000_000),
  maxEnergy: z.number().int().min(1).max(1_000_000),
  energyRegenPerSec: z.number().min(0).max(10_000),
  energyPerTap: z.number().min(0.01).max(10_000),
  maxTapsPerSec: z.number().min(0.1).max(50),
  tapBurst: z.number().int().min(1).max(500),
  referralReward: z.number().min(0).max(1_000_000_000),
  referredReward: z.number().min(0).max(1_000_000_000),
  dailyTapLimit: z.number().int().min(0).max(100_000_000),
  minWithdraw: z.number().min(0).max(1_000_000_000),
  withdrawalsEnabled: z.boolean(),
  withdrawOpenAt: z.string().datetime({ offset: true }).nullable(),
  ipCheckEnabled: z.boolean(),
  fraudPenalty: z.number().min(0).max(1_000_000_000),
});

adminRouter.get('/settings', async (_req, res) => {
  const { id: _id, ...rest } = await getSettings();
  res.json(rest);
});

adminRouter.put('/settings', async (req, res) => {
  const p = settingsSchema.partial().safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Noto\'g\'ri qiymatlar', details: p.error.flatten() });
  await getSettings(); // qator mavjudligini ta'minlaydi
  const { withdrawOpenAt, ...rest } = p.data;
  const data = { ...rest, ...(withdrawOpenAt === undefined ? {} : { withdrawOpenAt: withdrawOpenAt ? new Date(withdrawOpenAt) : null }) };
  const { id: _id, ...updated } = await prisma.settings.update({ where: { id: 1 }, data });
  invalidateSettings();
  res.json(updated);
});

/* ---- Vazifalar CRUD ---- */
const taskSchema = z.object({
  title: z.string().min(1).max(200),
  url: z.string().url().max(500).nullable().optional(),
  type: z.enum(['YOUTUBE', 'TELEGRAM', 'INVITE']),
  reward: z.number().min(0).max(1_000_000_000),
  chatId: z.string().max(100).nullable().optional(),
  requiredCount: z.number().int().min(1).max(10_000).optional(),
  active: z.boolean().optional(),
});

adminRouter.get('/tasks', async (_req, res) => {
  const tasks = await prisma.task.findMany({ orderBy: { id: 'desc' }, include: { _count: { select: { userTasks: true } } } });
  const completed = await prisma.userTask.groupBy({ by: ['taskId'], where: { completedAt: { not: null } }, _count: true });
  const cm = new Map(completed.map((c) => [c.taskId, c._count]));
  res.json(tasks.map((t) => ({ ...t, completedCount: cm.get(t.id) ?? 0 })));
});

adminRouter.post('/tasks', async (req, res) => {
  const p = taskSchema.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Noto\'g\'ri maydonlar', details: p.error.flatten() });
  res.json(await prisma.task.create({ data: p.data }));
});

adminRouter.put('/tasks/:id', async (req, res) => {
  const p = taskSchema.partial().safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Noto\'g\'ri maydonlar', details: p.error.flatten() });
  try {
    res.json(await prisma.task.update({ where: { id: Number(req.params.id) }, data: p.data }));
  } catch {
    res.status(404).json({ error: 'Vazifa topilmadi' });
  }
});

adminRouter.delete('/tasks/:id', async (req, res) => {
  try {
    await prisma.task.delete({ where: { id: Number(req.params.id) } });
    res.json({ ok: true });
  } catch {
    res.status(404).json({ error: 'Vazifa topilmadi' });
  }
});

/* ---- Foydalanuvchilar ---- */
adminRouter.get('/users', async (req, res) => {
  const q = String(req.query.search || '').trim();
  const page = Math.max(1, Number(req.query.page) || 1);
  const take = 25;
  const where = q
    ? {
        OR: [
          { telegramId: { contains: q } },
          { username: { contains: q, mode: 'insensitive' as const } },
          { firstName: { contains: q, mode: 'insensitive' as const } },
        ],
      }
    : {};
  const [total, users] = await Promise.all([
    prisma.user.count({ where }),
    prisma.user.findMany({
      where,
      orderBy: { balance: 'desc' },
      skip: (page - 1) * take,
      take,
      select: {
        id: true, telegramId: true, username: true, firstName: true, balance: true,
        totalEarned: true, banned: true, lastSeenAt: true, createdAt: true,
        _count: { select: { invitees: true } },
      },
    }),
  ]);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / take)), users });
});

adminRouter.patch('/users/:id', async (req, res) => {
  const p = z
    .object({ balance: z.number().min(0).max(1e12).optional(), banned: z.boolean().optional() })
    .safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Noto\'g\'ri qiymatlar' });
  try {
    const u = await prisma.user.update({ where: { id: Number(req.params.id) }, data: p.data });
    res.json({ id: u.id, balance: u.balance, banned: u.banned });
  } catch {
    res.status(404).json({ error: 'Foydalanuvchi topilmadi' });
  }
});

/* ---- Yechib olish so'rovlari ---- */
adminRouter.get('/withdrawals', async (req, res) => {
  const status = String(req.query.status || 'PENDING');
  const where = ['PENDING', 'PAID', 'REJECTED'].includes(status) ? { status: status as 'PENDING' | 'PAID' | 'REJECTED' } : {};
  const list = await prisma.withdrawal.findMany({
    where,
    orderBy: { id: 'desc' },
    take: 100,
    include: { user: { select: { firstName: true, username: true, telegramId: true } } },
  });
  res.json(list);
});

adminRouter.patch('/withdrawals/:id', async (req, res) => {
  const p = z.object({ status: z.enum(['PAID', 'REJECTED']) }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "Noto'g'ri holat" });
  const id = Number(req.params.id);
  const ok = await prisma.$transaction(async (tx) => {
    const r = await tx.withdrawal.updateMany({
      where: { id, status: 'PENDING' },
      data: { status: p.data.status, processedAt: new Date() },
    });
    if (r.count !== 1) return false;
    if (p.data.status === 'REJECTED') {
      const w = await tx.withdrawal.findUniqueOrThrow({ where: { id } });
      await tx.user.update({ where: { id: w.userId }, data: { balance: { increment: w.amount } } }); // qaytariladi
    }
    return true;
  });
  if (!ok) return res.status(409).json({ error: "So'rov allaqachon ko'rib chiqilgan yoki topilmadi" });
  res.json({ ok: true });
});

/* ---- Soxta referal (IP) hodisalari ---- */
adminRouter.get('/fraud', async (_req, res) => {
  const events = await prisma.fraudEvent.findMany({ orderBy: { id: 'desc' }, take: 30 });
  const ids = [...new Set(events.flatMap((e) => [e.inviterId, e.inviteeId]))];
  const users = await prisma.user.findMany({ where: { id: { in: ids } }, select: { id: true, firstName: true, username: true, telegramId: true } });
  const um = new Map(users.map((u) => [u.id, u]));
  res.json(events.map((e) => ({ ...e, inviter: um.get(e.inviterId) ?? null, invitee: um.get(e.inviteeId) ?? null })));
});

/* ---- Majburiy obuna kanallari ---- */
const channelSchema = z.object({
  title: z.string().min(1).max(100),
  chatId: z.string().regex(/^(@[A-Za-z0-9_]{4,64}|-100\d{5,})$/, "Kanal @username yoki -100... ko'rinishida bo'lsin"),
  url: z.string().url().max(300),
  active: z.boolean().optional(),
});

adminRouter.get('/channels', async (_req, res) => {
  res.json(await prisma.requiredChannel.findMany({ orderBy: { id: 'asc' } }));
});

adminRouter.post('/channels', async (req, res) => {
  const p = channelSchema.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: p.error.issues[0]?.message || "Noto'g'ri maydonlar" });
  const c = await prisma.requiredChannel.create({ data: p.data });
  invalidateChannels();
  res.json(c);
});

adminRouter.put('/channels/:id', async (req, res) => {
  const p = channelSchema.partial().safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: p.error.issues[0]?.message || "Noto'g'ri maydonlar" });
  try {
    const c = await prisma.requiredChannel.update({ where: { id: Number(req.params.id) }, data: p.data });
    invalidateChannels();
    res.json(c);
  } catch {
    res.status(404).json({ error: 'Kanal topilmadi' });
  }
});

adminRouter.delete('/channels/:id', async (req, res) => {
  try {
    await prisma.requiredChannel.delete({ where: { id: Number(req.params.id) } });
    invalidateChannels();
    res.json({ ok: true });
  } catch {
    res.status(404).json({ error: 'Kanal topilmadi' });
  }
});
