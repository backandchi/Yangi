import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { config } from '../config';
import { prisma } from '../db';
import { requireUser } from '../auth';
import { getSettings } from '../settings';
import { isChatMember } from '../telegramApi';

export const userRouter = Router();
userRouter.use(requireUser);

const tapLimiter = rateLimit({
  windowMs: 60_000,
  limit: 90,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.user?.telegramId ?? 'anon',
});

const todayKey = (d = new Date()) => d.toISOString().slice(0, 10);

function referralLink(tgId: string) {
  return config.botUsername ? `https://t.me/${config.botUsername}?start=ref_${tgId}` : '';
}

function currentEnergy(user: { energy: number; lastTapTime: Date }, s: { maxEnergy: number; energyRegenPerSec: number }) {
  const dt = Math.max(0, (Date.now() - user.lastTapTime.getTime()) / 1000);
  return Math.min(s.maxEnergy, user.energy + dt * s.energyRegenPerSec);
}

userRouter.get('/me', async (req, res) => {
  const u = req.user!;
  const s = await getSettings();
  await prisma.user.update({ where: { id: u.id }, data: { lastSeenAt: new Date() } });
  const isToday = u.dailyDate === todayKey();
  const dailyEarned = isToday ? u.dailyEarned : 0;
  const dailyTaps = isToday ? u.dailyTaps : 0;
  res.json({
    id: u.id,
    telegramId: u.telegramId,
    firstName: u.firstName,
    username: u.username,
    balance: u.balance,
    totalEarned: u.totalEarned,
    energy: currentEnergy(u, s),
    dailyEarned,
    dailyTaps,
    referralLink: referralLink(u.telegramId),
    settings: {
      perTap: s.pointsPerTap * s.globalMultiplier,
      maxEnergy: s.maxEnergy,
      energyRegenPerSec: s.energyRegenPerSec,
      energyPerTap: s.energyPerTap,
      dailyLimit: s.dailyLimit,
      dailyTapLimit: s.dailyTapLimit,
      referralReward: s.referralReward,
      referredReward: s.referredReward,
    },
  });
});

/**
 * Kliklar serverda tekshiriladi:
 *  - energiya (sekundiga tiklanish bilan),
 *  - sekundiga maksimal klik ("token bucket"),
 *  - kunlik ishlash limiti.
 */
userRouter.post('/tap', tapLimiter, async (req, res) => {
  const parsed = z.object({ count: z.number().int().min(1).max(500) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Noto\'g\'ri so\'rov' });
  const { count } = parsed.data;
  const userId = req.user!.id;
  const s = await getSettings();

  const result = await prisma.$transaction(async (tx) => {
    // bir vaqtda kelgan so'rovlar poygasini oldini olish uchun qatorni bloklaymiz
    await tx.$queryRaw`SELECT id FROM "User" WHERE id = ${userId} FOR UPDATE`;
    const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });

    const now = new Date();
    const dt = Math.max(0, (now.getTime() - user.lastTapTime.getTime()) / 1000);
    const energy = Math.min(s.maxEnergy, user.energy + dt * s.energyRegenPerSec);
    const tokens = Math.min(s.tapBurst, user.tapTokens + dt * s.maxTapsPerSec);
    const today = todayKey(now);
    const sameDay = user.dailyDate === today;
    const dailyEarned = sameDay ? user.dailyEarned : 0;
    const dailyTaps = sameDay ? user.dailyTaps : 0;
    const perTap = s.pointsPerTap * s.globalMultiplier;

    const byEnergy = Math.floor(energy / s.energyPerTap);
    const byTokens = Math.floor(tokens);
    const byDaily = perTap > 0 ? Math.floor(Math.max(0, s.dailyLimit - dailyEarned) / perTap + 1e-9) : 0;
    const byDailyTaps = Math.max(0, s.dailyTapLimit - dailyTaps);
    const accepted = Math.max(0, Math.min(count, byEnergy, byTokens, byDaily, byDailyTaps));

    const gain = Math.round(accepted * perTap * 10000) / 10000;
    const updated = await tx.user.update({
      where: { id: userId },
      data: {
        balance: { increment: gain },
        totalEarned: { increment: gain },
        energy: energy - accepted * s.energyPerTap,
        tapTokens: tokens - accepted,
        lastTapTime: now,
        dailyEarned: dailyEarned + gain,
        dailyTaps: dailyTaps + accepted,
        dailyDate: today,
        lastSeenAt: now,
      },
    });
    return { accepted, updated };
  });

  res.json({
    accepted: result.accepted,
    balance: result.updated.balance,
    energy: result.updated.energy,
    dailyEarned: result.updated.dailyEarned,
    dailyTaps: result.updated.dailyTaps,
  });
});

/* ---------------- Tasks ---------------- */

userRouter.get('/tasks', async (req, res) => {
  const u = req.user!;
  const tasks = await prisma.task.findMany({ where: { active: true }, orderBy: { id: 'asc' } });
  const done = await prisma.userTask.findMany({ where: { userId: u.id } });
  const doneMap = new Map(done.map((d) => [d.taskId, d]));
  const invited = await prisma.user.count({ where: { invitedById: u.id, welcomed: true, fraud: false } });
  res.json(
    tasks.map((t) => ({
      id: t.id,
      title: t.title,
      url: t.url,
      type: t.type,
      reward: t.reward,
      requiredCount: t.requiredCount,
      progress: t.type === 'INVITE' ? Math.min(invited, t.requiredCount) : undefined,
      started: !!doneMap.get(t.id),
      completed: !!doneMap.get(t.id)?.completedAt,
    })),
  );
});

userRouter.post('/tasks/:id/start', async (req, res) => {
  const id = Number(req.params.id);
  const task = await prisma.task.findFirst({ where: { id, active: true } });
  if (!task) return res.status(404).json({ error: 'Vazifa topilmadi' });
  await prisma.userTask.upsert({
    where: { userId_taskId: { userId: req.user!.id, taskId: id } },
    update: {},
    create: { userId: req.user!.id, taskId: id },
  });
  res.json({ ok: true });
});

userRouter.post('/tasks/:id/claim', async (req, res) => {
  const id = Number(req.params.id);
  const u = req.user!;
  const task = await prisma.task.findFirst({ where: { id, active: true } });
  if (!task) return res.status(404).json({ error: 'Vazifa topilmadi' });

  const existing = await prisma.userTask.findUnique({ where: { userId_taskId: { userId: u.id, taskId: id } } });
  if (existing?.completedAt) return res.status(409).json({ error: 'Vazifa allaqachon bajarilgan' });

  if (task.type === 'YOUTUBE') {
    if (!existing) return res.status(400).json({ error: 'Avval havolani oching' });
    const secs = (Date.now() - existing.startedAt.getTime()) / 1000;
    if (secs < config.youtubeMinSeconds) {
      return res.status(400).json({ error: `Videoni ko'rib bo'lgach ${Math.ceil(config.youtubeMinSeconds - secs)} soniyadan keyin urinib ko'ring` });
    }
  } else if (task.type === 'TELEGRAM') {
    if (!task.chatId) return res.status(500).json({ error: 'Vazifada kanal ko\'rsatilmagan' });
    const ok = await isChatMember(task.chatId, u.telegramId);
    if (!ok) return res.status(400).json({ error: 'Siz hali kanalga a\'zo emassiz' });
  } else if (task.type === 'INVITE') {
    const invited = await prisma.user.count({ where: { invitedById: u.id, welcomed: true, fraud: false } });
    if (invited < task.requiredCount) {
      return res.status(400).json({ error: `Yana ${task.requiredCount - invited} ta do'st taklif qiling` });
    }
  }

  const balance = await prisma.$transaction(async (tx) => {
    await tx.userTask.upsert({
      where: { userId_taskId: { userId: u.id, taskId: id } },
      update: {},
      create: { userId: u.id, taskId: id },
    });
    // updateMany + shart -> ikki marta ball olishning oldini oladi
    const r = await tx.userTask.updateMany({
      where: { userId: u.id, taskId: id, completedAt: null },
      data: { completedAt: new Date() },
    });
    if (r.count !== 1) return null;
    const updated = await tx.user.update({
      where: { id: u.id },
      data: { balance: { increment: task.reward }, totalEarned: { increment: task.reward } },
    });
    return updated.balance;
  });

  if (balance === null) return res.status(409).json({ error: 'Vazifa allaqachon bajarilgan' });
  res.json({ ok: true, reward: task.reward, balance });
});

/* ---------------- Friends ---------------- */

userRouter.get('/friends', async (req, res) => {
  const u = req.user!;
  const s = await getSettings();
  const [count, blocked, list] = await Promise.all([
    prisma.user.count({ where: { invitedById: u.id, welcomed: true, fraud: false } }),
    prisma.user.count({ where: { invitedById: u.id, fraud: true } }),
    prisma.user.findMany({
      where: { invitedById: u.id },
      orderBy: { createdAt: 'desc' },
      take: 100,
      select: { firstName: true, username: true, createdAt: true, fraud: true, welcomed: true },
    }),
  ]);
  res.json({
    count,
    blocked,
    link: referralLink(u.telegramId),
    referralReward: s.referralReward,
    referredReward: s.referredReward,
    fraudPenalty: s.fraudPenalty,
    friends: list,
  });
});

/* ---------------- Reyting (eng ko'p referal chaqirganlar) ---------------- */

userRouter.get('/leaderboard', async (req, res) => {
  const grouped = await prisma.user.groupBy({
    by: ['invitedById'],
    where: { invitedById: { not: null }, welcomed: true, fraud: false },
    _count: { id: true },
    orderBy: { _count: { id: 'desc' } },
    take: 50,
  });
  const ids = grouped.map((g) => g.invitedById as number);
  const users = await prisma.user.findMany({
    where: { id: { in: ids } },
    select: { id: true, firstName: true, username: true },
  });
  const um = new Map(users.map((u) => [u.id, u]));
  const top = grouped.map((g, i) => {
    const u = um.get(g.invitedById as number);
    return { rank: i + 1, name: u?.firstName ?? '—', username: u?.username ?? null, count: g._count.id, isMe: g.invitedById === req.user!.id };
  });
  const myCount = await prisma.user.count({ where: { invitedById: req.user!.id, welcomed: true, fraud: false } });
  res.json({ top, myCount });
});

/* ---------------- Yechib olish ---------------- */

const withdrawLimiter = rateLimit({
  windowMs: 60_000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.user?.telegramId ?? 'anon',
});

function withdrawState(s: { withdrawalsEnabled: boolean; withdrawOpenAt: Date | null }) {
  if (!s.withdrawalsEnabled) return { open: false, reason: 'Yechib olish vaqtincha yopiq' };
  if (s.withdrawOpenAt && s.withdrawOpenAt.getTime() > Date.now()) {
    return { open: false, reason: 'Yechib olish hali boshlanmagan' };
  }
  return { open: true, reason: '' };
}

userRouter.get('/withdraw', async (req, res) => {
  const u = req.user!;
  const s = await getSettings();
  const state = withdrawState(s);
  const history = await prisma.withdrawal.findMany({
    where: { userId: u.id },
    orderBy: { id: 'desc' },
    take: 20,
    select: { id: true, amount: true, robloxUsername: true, status: true, createdAt: true },
  });
  res.json({
    balance: u.balance,
    totalEarned: u.totalEarned,
    minWithdraw: s.minWithdraw,
    open: state.open,
    reason: state.reason,
    openAt: s.withdrawOpenAt,
    history,
  });
});

userRouter.post('/withdraw', withdrawLimiter, async (req, res) => {
  const p = z
    .object({
      amount: z.number().int().min(1).max(1_000_000_000),
      robloxUsername: z.string().trim().regex(/^[A-Za-z0-9_]{3,20}$/, 'Roblox username noto\'g\'ri'),
    })
    .safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: p.error.issues[0]?.message || 'Noto\'g\'ri ma\'lumot' });
  const s = await getSettings();
  const state = withdrawState(s);
  if (!state.open) {
    const when = s.withdrawOpenAt && s.withdrawalsEnabled ? ` (${s.withdrawOpenAt.toISOString().slice(0, 10)} dan)` : '';
    return res.status(403).json({ error: state.reason + when });
  }
  if (p.data.amount < s.minWithdraw) {
    return res.status(400).json({ error: `Minimal yechish miqdori: ${s.minWithdraw}` });
  }
  const userId = req.user!.id;
  const out = await prisma.$transaction(async (tx) => {
    await tx.$queryRaw`SELECT id FROM "User" WHERE id = ${userId} FOR UPDATE`;
    const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });
    if (user.balance < p.data.amount) return null;
    const upd = await tx.user.update({ where: { id: userId }, data: { balance: { decrement: p.data.amount } } });
    const w = await tx.withdrawal.create({
      data: { userId, amount: p.data.amount, robloxUsername: p.data.robloxUsername },
    });
    return { id: w.id, balance: upd.balance };
  });
  if (!out) return res.status(400).json({ error: 'Balans yetarli emas' });
  res.json({ ok: true, ...out });
});
