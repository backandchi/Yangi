import 'dotenv/config';

function required(name: string): string {
  const v = process.env[name];
  if (!v) {
    console.error(`[config] ${name} .env faylida ko'rsatilmagan`);
    process.exit(1);
  }
  return v;
}

export const config = {
  isProd: process.env.NODE_ENV === 'production',
  port: Number(process.env.PORT || 4000),
  botToken: required('BOT_TOKEN'),
  botUsername: process.env.BOT_USERNAME || '',
  webAppUrl: process.env.WEBAPP_URL || '',
  jwtSecret: required('JWT_SECRET'),
  adminIds: (process.env.ADMIN_IDS || '').split(',').map((s) => s.trim()).filter(Boolean),
  adminUsername: process.env.ADMIN_USERNAME || '',
  adminPassword: process.env.ADMIN_PASSWORD || '',
  corsOrigin: process.env.CORS_ORIGIN || '',
  // faqat development rejimida, Telegramsiz brauzerda sinash uchun
  devAuth: process.env.NODE_ENV !== 'production' && process.env.DEV_AUTH === 'true',
  youtubeMinSeconds: 20,
};
