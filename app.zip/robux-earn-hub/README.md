# Robux Earn Hub — Telegram Mini App (Tap-to-Earn)

Tarkib:

```
frontend/   Vite + React + Tailwind (Mini App + /admin sahifasi)
server/     Node.js + Express + Prisma + PostgreSQL (API + Telegram bot)
docker-compose.yml   db + server + web (Nginx)
ecosystem.config.js  Docker'siz variant uchun pm2
deploy/nginx-host.conf   serverdagi Nginx (SSL) namunasi
.env.example
```

> Eslatma: asl arxiv Next.js emas, **Vite + React** ekan — shuning uchun backend alohida Express server sifatida qo'shildi, `/admin` esa shu frontend ichida.

## 0. Railway'da ishga tushirish (tavsiya)

Nginx/Certbot kerak emas, HTTPS domen Railway'dan keladi.

1. Loyihani GitHub'ga yuklang (`.env` ni yuklamang).
2. Railway: **New Project → Deploy PostgreSQL**.
3. **New → GitHub Repo** (shu repo) → xizmat nomini `server` qiling. *Settings → Root Directory* = `/server`. Variables:
   - `DATABASE_URL` = `${{Postgres.DATABASE_URL}}`
   - `PORT` = `4000`, `NODE_ENV` = `production`
   - `BOT_TOKEN`, `BOT_USERNAME`, `JWT_SECRET`, `ADMIN_IDS`
   - `WEBAPP_URL` = frontend domeni (4-qadamdan keyin)
4. Yana **New → GitHub Repo** (shu repo) → nomi `web`. *Root Directory* = `/frontend`. Variables:
   - `PORT` = `8080`
   - `API_UPSTREAM` = `server.railway.internal:4000`
   - `DNS_RESOLVER` = `[fd12::10]`
   Keyin *Settings → Networking → Generate Domain* (target port: `8080`).
5. Hosil bo'lgan `https://web-xxxx.up.railway.app` ni `server` dagi `WEBAPP_URL` ga yozing (server qayta ishga tushadi) va BotFather'da Mini App URL qiling.
6. Tekshiring: `https://web-xxxx.up.railway.app/api/health` → `{"ok":true}`, admin: `/admin`.

Eslatma: bot long-polling ishlatadi, shuning uchun `server` xizmatini **bitta nusxada** (replica = 1) ushlang.
Quyidagi 1–10 bo'limlar VPS variantiga tegishli.

## 1. Oldindan tayyorlash

1. **Domen** (DuckDNS, Cloudflare yoki o'zingizniki) → A yozuvi VPS IP'siga. Masalan `app.sizning-domen.uz`.
2. **@BotFather**: `/newbot` → token va username oling.
3. **Admin ID**: Telegram'da @userinfobot ga yozib o'z ID'ngizni bilib oling.

## 2. VPS (Ubuntu 22.04/24.04) — Docker variant (tavsiya)

```bash
# Docker + Nginx + Certbot
sudo apt update && sudo apt install -y nginx certbot python3-certbot-nginx ca-certificates curl
curl -fsSL https://get.docker.com | sudo sh
sudo ufw allow OpenSSH && sudo ufw allow 'Nginx Full' && sudo ufw enable

# Loyihani serverga yuklang (scp / git / rsync), keyin:
cd robux-earn-hub
cp .env.example .env
nano .env        # BOT_TOKEN, BOT_USERNAME, WEBAPP_URL, ADMIN_IDS, JWT_SECRET, POSTGRES_PASSWORD
```

`DATABASE_URL` qatori Docker variantda ishlatilmaydi (compose o'zi yig'adi). `JWT_SECRET` uchun: `openssl rand -hex 32`.

```bash
sudo docker compose up -d --build
sudo docker compose logs -f server      # "[server] ..." va "[bot] polling boshlandi" chiqishi kerak
```

Baza jadvallari server ishga tushganda avtomatik yaratiladi (`prisma db push`).

## 3. Nginx + SSL

```bash
sudo cp deploy/nginx-host.conf /etc/nginx/sites-available/robux
sudo nano /etc/nginx/sites-available/robux          # server_name ni domeningizga almashtiring
sudo ln -s /etc/nginx/sites-available/robux /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d app.sizning-domen.uz
```

Tekshiring: `https://app.sizning-domen.uz/api/health` → `{"ok":true}`.

## 4. BotFather sozlamasi

- `/newapp` (yoki `/mybots → Bot Settings → Menu Button`) → URL: `https://app.sizning-domen.uz`
- Botga `/start` yuboring → "🚀 Ochish" tugmasi chiqadi.
- Referal havolasi: `https://t.me/BOT_USERNAME?start=ref_<telegram_id>` — bot `/start` ni ushlab, taklif qilganni eslab qoladi; do'st ilovani birinchi ochganda **ikkala tomonga** mukofot beriladi (bir marta).

## 5. Admin panel

- Ilova ichida "Admin" tugmasi yo'q. Admin panelga **faqat `ADMIN_IDS` dagi Telegram ID** egasi kira oladi: botga `/admin` yozing → "Admin panelni ochish" tugmasi chiqadi (ID serverda initData orqali tekshiriladi, login/parol yo'q).
- Bo'limlar: **Statistika** (jami foydalanuvchi, bugungi faollar, jami ishlangan Robux, soxta referallar), **Iqtisodiyot**, **Vazifalar** (CRUD), **Yechishlar** (To'landi / Rad etish), **Foydalanuvchilar** (balans tahriri, bloklash).
- Iqtisodiyotda admin belgilaydi: bir bosishdagi Robux, kuniga maks. bosishlar soni, qo'shimcha kunlik Robux limiti, global koeffitsient, energiya, anti-clicker, referal mukofotlari (ikkala tomon), minimal yechish miqdori, yechish ochilish sanasi, IP tekshiruvi va soxta referal jarimasi.

## 6. Vazifa turlari qanday tekshiriladi

| Tur | Server tekshiruvi |
|---|---|
| YouTube | Foydalanuvchi "Boshlash" bosgach kamida 20 soniya o'tishi shart (video ko'rilganini haqiqatda tekshirib bo'lmaydi — bu faqat vaqt to'sig'i). |
| Telegram kanal | `getChatMember` orqali haqiqiy a'zolik. **Botni kanalga admin qiling**, vazifada kanalni `@kanal_username` ko'rinishida kiriting. |
| Do'st taklif | Kerakli do'stlar soni bazadan sanaladi. |

Har bir vazifa har bir foydalanuvchiga **faqat bir marta** to'lanadi (DB darajasida `unique` + atomik yangilash).

## 7. Anti-cheat qanday ishlaydi

- Har so'rovda `initData` HMAC-SHA256 bilan tekshiriladi (24 soatdan eski bo'lsa rad etiladi).
- Frontend kliklarni 1.5 soniyada bir marta paketlab yuboradi; **ball serverda hisoblanadi**, mijoz faqat "n ta klik" deydi.
- Server: energiya (tiklanish bilan), sekundiga maks. klik (token-bucket + burst), kunlik limit — uchalasi bo'yicha qabul qilinadigan kliklar sonini cheklaydi. Bir foydalanuvchining parallel so'rovlari DB qatorini bloklab ketma-ket bajariladi.
- `/api/tap` uchun foydalanuvchi bo'yicha daqiqasiga 90 so'rov limiti; admin login uchun IP bo'yicha 15 daqiqada 10 urinish.

Kunlik limit faqat **tap** orqali ishlanganiga tegishli; vazifa va referal mukofotlari unga kirmaydi.

## 8. Docker'siz variant (pm2)

```bash
sudo apt install -y nginx postgresql
# Node 20: https://github.com/nodesource/distributions
sudo npm i -g pm2
sudo -u postgres psql -c "CREATE USER robux WITH PASSWORD '...';" -c "CREATE DATABASE robux OWNER robux;"
cp .env.example .env && nano .env         # DATABASE_URL ni to'g'rilang
cd server && npm ci && npm run build && npx prisma db push && cd ..
cd frontend && npm ci && npm run build && sudo mkdir -p /var/www/robux && sudo cp -r dist/* /var/www/robux/ && cd ..
pm2 start ecosystem.config.js && pm2 save && pm2 startup
```

So'ng `deploy/nginx-host.conf` dagi **Variant B** blokini yoqing (Variant A'ni o'chiring) va certbot'ni ishga tushiring.

## 9. Lokal sinov

```bash
# server/.env (yoki ildizdagi .env) da: DEV_AUTH=true, DATABASE_URL=...
cd server && npm i && npx prisma db push && npm run dev
cd frontend && npm i && npm run dev       # brauzerda Telegram'siz ham ochiladi (dev rejimida)
```

## 10. Yangilash / zaxira

```bash
sudo docker compose up -d --build                                   # kod yangilanganda
sudo docker compose exec db pg_dump -U robux robux > backup.sql      # zaxira nusxa
```

## Muhim eslatmalar

- `.env` ni hech qachon git'ga yuklamang; bot tokeni oshkor bo'lsa BotFather'da `/revoke` qiling.
- Kod bu yerda sinov muhitida **ishga tushirib tekshirilmagan** (internet yo'qligi sababli paketlar o'rnatilmagan). Birinchi ishga tushirishda `docker compose logs` ni kuzating — kichik tuzatishlar kerak bo'lishi mumkin.
- Ilovadagi "Robux ball" — bu ichki ball. Haqiqiy Robux berish (yoki o'yin ichidagi valyuta va'dasi) uchun Roblox qoidalari va sizning mamlakatingiz qonunlarini tekshiring: Roblox "Robux olish" uchun uchinchi tomon saytlarini taqiqlaydi, auditoriyangizni chalg'itmaslik uchun ilova ichida mukofot nima ekanini aniq yozib qo'ying.

## Yangi imkoniyatlar (oq-tilla dizayn versiyasi)

- **Reyting**: eng ko'p do'st taklif qilgan 50 ta foydalanuvchi.
- **Yechish**: foydalanuvchi Roblox username kiritadi; miqdor minimal limitdan kam bo'lmasligi kerak; admin belgilagan sanagacha yopiq turishi mumkin. So'rov yuborilganda Robux balansdan darhol ushlanadi; admin "To'landi" yoki "Rad etish" (rad etilsa balansga qaytadi) belgilaydi. Robux ni haqiqatda Roblox'da admin qo'lda yuboradi.
- **IP tekshiruv**: yangi do'stning IP si taklif qilganning IP siga teng bo'lsa yoki shu IP dan allaqachon mukofotli referal kirgan bo'lsa, bonus berilmaydi, referal hisobga olinmaydi va taklif qilgandan jarima ushlanadi. Eslatma: mobil operatorlar bitta IP ni ko'p abonentga berishi mumkin (CGNAT), shuning uchun ba'zan halol foydalanuvchilar ham tushib qolishi mumkin; kerak bo'lsa Iqtisodiyotdan IP tekshiruvini o'chiring.
