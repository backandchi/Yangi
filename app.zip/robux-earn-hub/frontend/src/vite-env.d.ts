/// <reference types="vite/client" />

interface TgWebApp {
  initData: string;
  ready(): void;
  expand(): void;
  openLink(url: string): void;
  openTelegramLink(url: string): void;
  HapticFeedback?: { impactOccurred(style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft'): void };
}

interface Window {
  Telegram?: { WebApp: TgWebApp };
}
