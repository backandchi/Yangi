import React, { useCallback, useEffect, useState } from 'react';
import { adminApi, adminToken, ApiError, fmt, tg } from '../api';

type Tab = 'stats' | 'economy' | 'tasks' | 'users';

const card = 'bg-[#272a2f] rounded-xl p-4';
const input = 'w-full bg-[#1d2025] border border-[#43433b] rounded-lg px-3 py-2 text-sm text-white';
const btn = 'rounded-lg px-3 py-2 text-sm';

/* ---------------- Login ---------------- */
const Login: React.FC<{ onLogin: () => void }> = ({ onLogin }) => {
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [err, setErr] = useState('');

  const submit = async () => {
    try {
      const r = await adminApi.login(u, p);
      adminToken.set(r.token);
      onLogin();
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : 'Xatolik');
    }
  };
  const tgLogin = async () => {
    try {
      const r = await adminApi.loginTelegram(tg?.initData || '');
      adminToken.set(r.token);
      onLogin();
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : 'Xatolik');
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div className={`${card} w-full max-w-sm space-y-3`}>
        <h1 className="text-xl font-bold">Admin panel</h1>
        <input className={input} placeholder="Login" value={u} onChange={(e) => setU(e.target.value)} />
        <input className={input} type="password" placeholder="Parol" value={p} onChange={(e) => setP(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && void submit()} />
        <button className={`${btn} bg-[#f3ba2f] text-black w-full`} onClick={() => void submit()}>Kirish</button>
        {tg?.initData && (
          <button className={`${btn} bg-[#5a60f0] w-full`} onClick={() => void tgLogin()}>Telegram ID orqali kirish</button>
        )}
        {err && <p className="text-red-400 text-sm">{err}</p>}
      </div>
    </div>
  );
};

/* ---------------- Stats ---------------- */
interface Stats {
  totalUsers: number; activeToday: number; newToday: number; banned: number; totalEarned: number; totalBalance: number;
}
const StatsTab: React.FC = () => {
  const [s, setS] = useState<Stats | null>(null);
  useEffect(() => { adminApi.get<Stats>('/stats').then(setS).catch(() => undefined); }, []);
  if (!s) return <p>Yuklanmoqda...</p>;
  const items: [string, number][] = [
    ['Jami foydalanuvchilar', s.totalUsers],
    ['Bugungi faollar (UTC)', s.activeToday],
    ['Bugun qo\'shilganlar', s.newToday],
    ['Bloklanganlar', s.banned],
    ['Jami ishlangan ballar', s.totalEarned],
    ['Foydalanuvchilar balansi yig\'indisi', s.totalBalance],
  ];
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
      {items.map(([k, v]) => (
        <div key={k} className={card}>
          <p className="text-xs text-[#85827d]">{k}</p>
          <p className="text-2xl mt-1">{fmt(v)}</p>
        </div>
      ))}
    </div>
  );
};

/* ---------------- Economy ---------------- */
interface SettingsT {
  pointsPerTap: number; globalMultiplier: number; dailyLimit: number; maxEnergy: number; energyRegenPerSec: number;
  energyPerTap: number; maxTapsPerSec: number; tapBurst: number; referralReward: number; referredReward: number;
}
const fields: [keyof SettingsT, string][] = [
  ['pointsPerTap', 'Bir klik uchun ball (1 = 1x, 2 = 2x, 0.5 = 0.5x)'],
  ['globalMultiplier', 'Global balans koeffitsienti'],
  ['dailyLimit', 'Kunlik maksimal ishlash limiti (tap orqali)'],
  ['maxEnergy', 'Maksimal energiya'],
  ['energyRegenPerSec', 'Energiya tiklanishi (sekundiga)'],
  ['energyPerTap', 'Bir klik uchun energiya sarfi'],
  ['maxTapsPerSec', 'Anti-clicker: sekundiga maks. klik'],
  ['tapBurst', 'Anti-clicker: bir martalik maks. burst'],
  ['referralReward', 'Referal: taklif qilganga mukofot'],
  ['referredReward', 'Referal: taklif qilinganga mukofot'],
];

const EconomyTab: React.FC = () => {
  const [s, setS] = useState<Record<string, string> | null>(null);
  const [mult, setMult] = useState(1);
  const [msg, setMsg] = useState('');

  const load = useCallback(async () => {
    const r = await adminApi.get<SettingsT>('/settings');
    setMult(r.globalMultiplier);
    setS(Object.fromEntries(Object.entries(r).map(([k, v]) => [k, String(v)])));
  }, []);
  useEffect(() => { void load(); }, [load]);

  const save = async (override?: Partial<SettingsT>) => {
    if (!s) return;
    const body: Record<string, number> = {};
    for (const [k] of fields) body[k] = Number(s[k]);
    Object.assign(body, override);
    try {
      await adminApi.put('/settings', body);
      setMsg('Saqlandi ✓');
      await load();
    } catch (e) {
      setMsg(e instanceof ApiError ? e.message : 'Xatolik');
    }
    setTimeout(() => setMsg(''), 2500);
  };

  if (!s) return <p>Yuklanmoqda...</p>;
  return (
    <div className="space-y-4">
      <div className={card}>
        <p className="text-sm mb-2">Butun ilova balans koeffitsienti: <b>{mult}x</b></p>
        <div className="flex flex-wrap gap-2">
          {[0.25, 0.5, 1, 2, 5].map((m) => (
            <button key={m} className={`${btn} ${mult === m ? 'bg-[#f3ba2f] text-black' : 'bg-[#43433b]'}`}
              onClick={() => void save({ globalMultiplier: m })}>{m}x</button>
          ))}
        </div>
      </div>
      <div className={`${card} grid md:grid-cols-2 gap-3`}>
        {fields.map(([k, label]) => (
          <label key={k} className="text-xs text-[#85827d]">
            {label}
            <input className={`${input} mt-1`} type="number" step="any" value={s[k]}
              onChange={(e) => setS({ ...s, [k]: e.target.value })} />
          </label>
        ))}
      </div>
      <div className="flex items-center gap-3">
        <button className={`${btn} bg-[#f3ba2f] text-black`} onClick={() => void save()}>Saqlash</button>
        <span className="text-sm text-green-400">{msg}</span>
      </div>
    </div>
  );
};

/* ---------------- Tasks ---------------- */
interface AdminTask {
  id: number; title: string; url: string | null; type: 'YOUTUBE' | 'TELEGRAM' | 'INVITE'; reward: number;
  chatId: string | null; requiredCount: number; active: boolean; completedCount: number;
}
const TasksTab: React.FC = () => {
  const [list, setList] = useState<AdminTask[]>([]);
  const [err, setErr] = useState('');
  const [f, setF] = useState({ title: '', url: '', type: 'YOUTUBE', reward: '100', chatId: '', requiredCount: '1' });

  const load = useCallback(async () => setList(await adminApi.get<AdminTask[]>('/tasks')), []);
  useEffect(() => { void load(); }, [load]);

  const add = async () => {
    setErr('');
    try {
      await adminApi.post('/tasks', {
        title: f.title,
        url: f.url.trim() || null,
        type: f.type,
        reward: Number(f.reward),
        chatId: f.type === 'TELEGRAM' ? f.chatId.trim() || null : null,
        requiredCount: f.type === 'INVITE' ? Number(f.requiredCount) : 1,
      });
      setF({ ...f, title: '', url: '' });
      await load();
    } catch (e) {
      setErr(e instanceof ApiError ? `${e.message} (havola to'liq https://... bo'lishi kerak)` : 'Xatolik');
    }
  };

  return (
    <div className="space-y-4">
      <div className={`${card} grid md:grid-cols-2 gap-3`}>
        <input className={input} placeholder="Sarlavha" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
        <select className={input} value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}>
          <option value="YOUTUBE">YouTube video ko'rish</option>
          <option value="TELEGRAM">Telegram kanalga a'zo bo'lish</option>
          <option value="INVITE">Do'st taklif qilish</option>
        </select>
        {f.type !== 'INVITE' && (
          <input className={input} placeholder="Havola (https://...)" value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} />
        )}
        {f.type === 'TELEGRAM' && (
          <input className={input} placeholder="Kanal: @kanal_username (bot kanalda admin bo'lishi shart)" value={f.chatId}
            onChange={(e) => setF({ ...f, chatId: e.target.value })} />
        )}
        {f.type === 'INVITE' && (
          <input className={input} type="number" placeholder="Kerakli do'stlar soni" value={f.requiredCount}
            onChange={(e) => setF({ ...f, requiredCount: e.target.value })} />
        )}
        <input className={input} type="number" placeholder="Mukofot balli" value={f.reward} onChange={(e) => setF({ ...f, reward: e.target.value })} />
        <button className={`${btn} bg-[#f3ba2f] text-black`} onClick={() => void add()}>Vazifa qo'shish</button>
        {err && <p className="text-red-400 text-sm md:col-span-2">{err}</p>}
      </div>

      <div className="space-y-2">
        {list.map((t) => (
          <div key={t.id} className={`${card} flex flex-wrap items-center justify-between gap-2 ${t.active ? '' : 'opacity-50'}`}>
            <div>
              <p>{t.title} <span className="text-xs text-[#85827d]">[{t.type}]</span></p>
              <p className="text-xs text-[#85827d] break-all">
                +{fmt(t.reward)} · bajarganlar: {t.completedCount} {t.url ? `· ${t.url}` : ''} {t.chatId ? `· ${t.chatId}` : ''}
              </p>
            </div>
            <div className="flex gap-2">
              <button className={`${btn} bg-[#43433b]`} onClick={async () => { await adminApi.put(`/tasks/${t.id}`, { active: !t.active }); await load(); }}>
                {t.active ? 'To\'xtatish' : 'Yoqish'}
              </button>
              <button className={`${btn} bg-red-700`} onClick={async () => {
                if (window.confirm('Vazifa o\'chirilsinmi?')) { await adminApi.del(`/tasks/${t.id}`); await load(); }
              }}>O'chirish</button>
            </div>
          </div>
        ))}
        {list.length === 0 && <p className="text-[#85827d] text-sm">Vazifalar yo'q</p>}
      </div>
    </div>
  );
};

/* ---------------- Users ---------------- */
interface AdminUser {
  id: number; telegramId: string; username: string | null; firstName: string; balance: number; totalEarned: number;
  banned: boolean; lastSeenAt: string; _count: { invitees: number };
}
const UsersTab: React.FC = () => {
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState<{ users: AdminUser[]; pages: number; total: number } | null>(null);
  const [edit, setEdit] = useState<{ id: number; value: string } | null>(null);

  const load = useCallback(async () => {
    setData(await adminApi.get<{ users: AdminUser[]; pages: number; total: number }>(`/users?search=${encodeURIComponent(q)}&page=${page}`));
  }, [q, page]);
  useEffect(() => { void load(); }, [load]);

  return (
    <div className="space-y-3">
      <input className={input} placeholder="Qidirish: ID, username yoki ism" value={q}
        onChange={(e) => { setPage(1); setQ(e.target.value); }} />
      <p className="text-xs text-[#85827d]">Jami: {data?.total ?? '...'}</p>
      {data?.users.map((u) => (
        <div key={u.id} className={`${card} ${u.banned ? 'border border-red-700' : ''}`}>
          <div className="flex flex-wrap justify-between gap-2">
            <div>
              <p>{u.firstName} {u.username && <span className="text-[#85827d]">@{u.username}</span>}</p>
              <p className="text-xs text-[#85827d]">
                TG: {u.telegramId} · do'stlar: {u._count.invitees} · jami ishlagan: {fmt(u.totalEarned)} · oxirgi: {new Date(u.lastSeenAt).toLocaleString()}
              </p>
            </div>
            <div className="text-right">
              {edit?.id === u.id ? (
                <div className="flex gap-2">
                  <input className={`${input} w-32`} type="number" value={edit.value} onChange={(e) => setEdit({ id: u.id, value: e.target.value })} />
                  <button className={`${btn} bg-[#f3ba2f] text-black`} onClick={async () => {
                    await adminApi.patch(`/users/${u.id}`, { balance: Number(edit.value) });
                    setEdit(null); await load();
                  }}>OK</button>
                  <button className={`${btn} bg-[#43433b]`} onClick={() => setEdit(null)}>×</button>
                </div>
              ) : (
                <>
                  <p className="text-lg">{fmt(u.balance)}</p>
                  <div className="flex gap-2 mt-1 justify-end">
                    <button className={`${btn} bg-[#43433b]`} onClick={() => setEdit({ id: u.id, value: String(u.balance) })}>Balans</button>
                    <button className={`${btn} ${u.banned ? 'bg-green-700' : 'bg-red-700'}`} onClick={async () => {
                      await adminApi.patch(`/users/${u.id}`, { banned: !u.banned }); await load();
                    }}>{u.banned ? 'Blokdan chiqarish' : 'Bloklash'}</button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      ))}
      <div className="flex items-center gap-3 justify-center">
        <button className={`${btn} bg-[#43433b]`} disabled={page <= 1} onClick={() => setPage(page - 1)}>←</button>
        <span className="text-sm">{page} / {data?.pages ?? 1}</span>
        <button className={`${btn} bg-[#43433b]`} disabled={!data || page >= data.pages} onClick={() => setPage(page + 1)}>→</button>
      </div>
    </div>
  );
};

/* ---------------- Root ---------------- */
const Admin: React.FC = () => {
  const [authed, setAuthed] = useState(!!adminToken.get());
  const [tab, setTab] = useState<Tab>('stats');

  // token eskirsa yoki noto'g'ri bo'lsa login oynasiga qaytadi
  useEffect(() => {
    if (!authed) return;
    adminApi.get('/stats').catch((e) => {
      if (e instanceof ApiError && (e.status === 401 || e.status === 403)) {
        adminToken.clear();
        setAuthed(false);
      }
    });
  }, [authed]);

  if (!authed) return <Login onLogin={() => setAuthed(true)} />;

  const tabs: [Tab, string][] = [['stats', 'Statistika'], ['economy', 'Iqtisodiyot'], ['tasks', 'Vazifalar'], ['users', 'Foydalanuvchilar']];
  return (
    <div className="min-h-screen bg-black text-white">
      <div className="max-w-4xl mx-auto p-4">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold">Robux Earn Hub · Admin</h1>
          <button className={`${btn} bg-[#43433b]`} onClick={() => { adminToken.clear(); setAuthed(false); }}>Chiqish</button>
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          {tabs.map(([t, l]) => (
            <button key={t} onClick={() => setTab(t)} className={`${btn} ${tab === t ? 'bg-[#f3ba2f] text-black' : 'bg-[#272a2f]'}`}>{l}</button>
          ))}
        </div>
        {tab === 'stats' && <StatsTab />}
        {tab === 'economy' && <EconomyTab />}
        {tab === 'tasks' && <TasksTab />}
        {tab === 'users' && <UsersTab />}
      </div>
    </div>
  );
};

export default Admin;
