import React, { useCallback, useEffect, useState } from 'react';
import { adminApi, adminToken, ApiError, fmt, tg } from '../api';

type Tab = 'stats' | 'economy' | 'tasks' | 'channels' | 'withdraw' | 'users';

const card = 'bg-[#272a2f] rounded-xl p-4';
const input = 'w-full bg-[#1d2025] border border-[#43433b] rounded-lg px-3 py-2 text-sm text-white';
const btn = 'rounded-lg px-3 py-2 text-sm';

/* ---------------- Telegram ID orqali kirish ---------------- */
const Login: React.FC<{ onLogin: () => void }> = ({ onLogin }) => {
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const tgLogin = useCallback(async () => {
    setBusy(true);
    setErr('');
    try {
      const r = await adminApi.loginTelegram(tg?.initData || '');
      adminToken.set(r.token);
      onLogin();
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : 'Xatolik');
    } finally {
      setBusy(false);
    }
  }, [onLogin]);

  useEffect(() => {
    if (tg?.initData) void tgLogin();
  }, [tgLogin]);

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div className={`${card} w-full max-w-sm space-y-3 text-center`}>
        <h1 className="text-xl font-bold">Admin panel</h1>
        {tg?.initData ? (
          <>
            <p className="text-sm text-[#85827d]">Telegram ID tekshirilmoqda...</p>
            <button className={`${btn} bg-[#f3ba2f] text-black w-full`} disabled={busy} onClick={() => void tgLogin()}>
              Qayta urinish
            </button>
          </>
        ) : (
          <p className="text-sm text-[#85827d]">
            Admin panelga faqat Telegram ichidan kiriladi. Botga <b>/admin</b> deb yozing va chiqqan tugmani bosing.
          </p>
        )}
        {err && <p className="text-red-400 text-sm">{err}</p>}
      </div>
    </div>
  );
};

/* ---------------- Stats ---------------- */
interface Stats {
  totalUsers: number; activeToday: number; newToday: number; banned: number; totalEarned: number; totalBalance: number;
  pendingWithdrawals: number; totalWithdrawn: number; fraudBlocked: number;
}
interface FraudRow {
  id: number; ip: string | null; penalty: number; createdAt: string;
  inviter: { firstName: string; username: string | null; telegramId: string } | null;
  invitee: { firstName: string; username: string | null; telegramId: string } | null;
}
const StatsTab: React.FC = () => {
  const [s, setS] = useState<Stats | null>(null);
  const [fraud, setFraud] = useState<FraudRow[]>([]);
  useEffect(() => {
    adminApi.get<Stats>('/stats').then(setS).catch(() => undefined);
    adminApi.get<FraudRow[]>('/fraud').then(setFraud).catch(() => undefined);
  }, []);
  if (!s) return <p>Yuklanmoqda...</p>;
  const items: [string, number][] = [
    ['Jami foydalanuvchilar', s.totalUsers],
    ['Bugungi faollar (UTC)', s.activeToday],
    ["Bugun qo'shilganlar", s.newToday],
    ['Bloklanganlar', s.banned],
    ['Jami ishlangan Robux', s.totalEarned],
    ["Foydalanuvchilar balansi yig'indisi", s.totalBalance],
    ["Kutilayotgan yechishlar", s.pendingWithdrawals],
    ["Jami to'langan (yechilgan)", s.totalWithdrawn],
    ['IP orqali bloklangan referallar', s.fraudBlocked],
  ];
  const nm = (u: FraudRow['inviter']) => (u ? `${u.firstName}${u.username ? ' @' + u.username : ''} (${u.telegramId})` : '—');
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {items.map(([k, v]) => (
          <div key={k} className={card}>
            <p className="text-xs text-[#85827d]">{k}</p>
            <p className="text-2xl mt-1">{fmt(v)}</p>
          </div>
        ))}
      </div>
      <div className={card}>
        <p className="text-sm mb-2">Oxirgi soxta referal hodisalari (IP)</p>
        {fraud.length === 0 && <p className="text-xs text-[#85827d]">Hali yo'q</p>}
        {fraud.map((f) => (
          <p key={f.id} className="text-xs text-[#85827d] border-t border-[#43433b] py-1 break-all">
            Taklif qilgan: {nm(f.inviter)} → yangi: {nm(f.invitee)} · IP {f.ip} · jarima −{fmt(f.penalty)} · {new Date(f.createdAt).toLocaleString()}
          </p>
        ))}
      </div>
    </div>
  );
};

/* ---------------- Economy ---------------- */
interface SettingsT {
  pointsPerTap: number; globalMultiplier: number; dailyLimit: number; dailyTapLimit: number; maxEnergy: number;
  energyRegenPerSec: number; energyPerTap: number; maxTapsPerSec: number; tapBurst: number; referralReward: number;
  referredReward: number; minWithdraw: number; fraudPenalty: number; withdrawalsEnabled: boolean; ipCheckEnabled: boolean;
  withdrawOpenAt: string | null;
}
type NumKey = Exclude<keyof SettingsT, 'withdrawalsEnabled' | 'ipCheckEnabled' | 'withdrawOpenAt'>;
const fields: [NumKey, string][] = [
  ['pointsPerTap', 'Bir bosishda necha Robux (1 = 1x, 2 = 2x, 0.5 = 0.5x)'],
  ['dailyTapLimit', 'Kuniga maksimal bosishlar soni'],
  ['dailyLimit', "Kunlik maksimal ishlash (Robux, qo'shimcha limit)"],
  ['globalMultiplier', 'Global balans koeffitsienti'],
  ['maxEnergy', 'Maksimal energiya'],
  ['energyRegenPerSec', 'Energiya tiklanishi (sekundiga)'],
  ['energyPerTap', 'Bir bosishga energiya sarfi'],
  ['maxTapsPerSec', 'Anti-clicker: sekundiga maks. bosish'],
  ['tapBurst', 'Anti-clicker: bir martalik maks. burst'],
  ['referralReward', 'Referal: taklif qilganga Robux'],
  ['referredReward', 'Referal: taklif qilinganga Robux'],
  ['fraudPenalty', "Soxta referal (bir IP): taklif qilgandan olib qo'yiladigan Robux"],
  ['minWithdraw', 'Minimal yechish miqdori (Robux)'],
];

const toLocalInput = (iso: string | null) => {
  if (!iso) return '';
  const d = new Date(iso);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};

const EconomyTab: React.FC = () => {
  const [num, setNum] = useState<Record<string, string> | null>(null);
  const [flags, setFlags] = useState({ withdrawalsEnabled: true, ipCheckEnabled: true });
  const [openAt, setOpenAt] = useState('');
  const [mult, setMult] = useState(1);
  const [msg, setMsg] = useState('');

  const load = useCallback(async () => {
    const r = await adminApi.get<SettingsT>('/settings');
    setMult(r.globalMultiplier);
    setNum(Object.fromEntries(fields.map(([k]) => [k, String(r[k])])));
    setFlags({ withdrawalsEnabled: r.withdrawalsEnabled, ipCheckEnabled: r.ipCheckEnabled });
    setOpenAt(toLocalInput(r.withdrawOpenAt));
  }, []);
  useEffect(() => { void load(); }, [load]);

  const save = async (override?: Record<string, unknown>, clearDate = false) => {
    if (!num) return;
    const body: Record<string, unknown> = {};
    for (const [k] of fields) body[k] = Number(num[k]);
    body.withdrawalsEnabled = flags.withdrawalsEnabled;
    body.ipCheckEnabled = flags.ipCheckEnabled;
    body.withdrawOpenAt = clearDate || !openAt ? null : new Date(openAt).toISOString();
    Object.assign(body, override);
    try {
      await adminApi.put('/settings', body);
      setMsg('Saqlandi ✓');
      await load();
    } catch (e) {
      setMsg(e instanceof ApiError ? e.message : 'Xatolik');
    }
    setTimeout(() => setMsg(''), 2500);
  };

  if (!num) return <p>Yuklanmoqda...</p>;
  return (
    <div className="space-y-4">
      <div className={card}>
        <p className="text-sm mb-2">Butun ilova balans koeffitsienti: <b>{mult}x</b></p>
        <div className="flex flex-wrap gap-2">
          {[0.25, 0.5, 1, 2, 5].map((m) => (
            <button key={m} className={`${btn} ${mult === m ? 'bg-[#f3ba2f] text-black' : 'bg-[#43433b]'}`}
              onClick={() => void save({ globalMultiplier: m })}>{m}x</button>
          ))}
        </div>
      </div>

      <div className={`${card} grid md:grid-cols-2 gap-3`}>
        {fields.filter(([k]) => k !== 'globalMultiplier').map(([k, label]) => (
          <label key={k} className="text-xs text-[#85827d]">
            {label}
            <input className={`${input} mt-1`} type="number" step="any" value={num[k]}
              onChange={(e) => setNum({ ...num, [k]: e.target.value })} />
          </label>
        ))}
      </div>

      <div className={`${card} space-y-3`}>
        <p className="text-sm">Yechib olish</p>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={flags.withdrawalsEnabled} onChange={(e) => setFlags({ ...flags, withdrawalsEnabled: e.target.checked })} />
          Yechib olish yoqilgan
        </label>
        <label className="text-xs text-[#85827d] block">
          Shu sanagacha yechib olish yopiq (bo'sh = hozir ochiq)
          <input className={`${input} mt-1`} type="datetime-local" value={openAt} onChange={(e) => setOpenAt(e.target.value)} />
        </label>
        <button className={`${btn} bg-[#43433b]`} onClick={() => { setOpenAt(''); void save(undefined, true); }}>Sanani olib tashlash (hozir ochish)</button>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={flags.ipCheckEnabled} onChange={(e) => setFlags({ ...flags, ipCheckEnabled: e.target.checked })} />
          IP tekshiruvi (bir telefon/IP dan takroriy referal bo'lsa bonus berilmaydi)
        </label>
      </div>

      <div className="flex items-center gap-3">
        <button className={`${btn} bg-[#f3ba2f] text-black`} onClick={() => void save()}>Saqlash</button>
        <span className="text-sm text-green-400">{msg}</span>
      </div>
    </div>
  );
};

/* ---------------- Tasks ---------------- */
interface AdminTask {
  id: number; title: string; url: string | null; type: 'YOUTUBE' | 'TELEGRAM' | 'INVITE'; reward: number;
  chatId: string | null; requiredCount: number; active: boolean; completedCount: number;
}
const TasksTab: React.FC = () => {
  const [list, setList] = useState<AdminTask[]>([]);
  const [err, setErr] = useState('');
  const [f, setF] = useState({ title: '', url: '', type: 'YOUTUBE', reward: '100', chatId: '', requiredCount: '1' });

  const load = useCallback(async () => setList(await adminApi.get<AdminTask[]>('/tasks')), []);
  useEffect(() => { void load(); }, [load]);

  const add = async () => {
    setErr('');
    try {
      await adminApi.post('/tasks', {
        title: f.title,
        url: f.url.trim() || null,
        type: f.type,
        reward: Number(f.reward),
        chatId: f.type === 'TELEGRAM' ? f.chatId.trim() || null : null,
        requiredCount: f.type === 'INVITE' ? Number(f.requiredCount) : 1,
      });
      setF({ ...f, title: '', url: '' });
      await load();
    } catch (e) {
      setErr(e instanceof ApiError ? `${e.message} (havola to'liq https://... bo'lishi kerak)` : 'Xatolik');
    }
  };

  return (
    <div className="space-y-4">
      <div className={`${card} grid md:grid-cols-2 gap-3`}>
        <input className={input} placeholder="Sarlavha" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
        <select className={input} value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}>
          <option value="YOUTUBE">YouTube video ko'rish</option>
          <option value="TELEGRAM">Telegram kanalga a'zo bo'lish</option>
          <option value="INVITE">Do'st taklif qilish</option>
        </select>
        {f.type !== 'INVITE' && (
          <input className={input} placeholder="Havola (https://...)" value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} />
        )}
        {f.type === 'TELEGRAM' && (
          <input className={input} placeholder="Kanal: @kanal_username (bot kanalda admin bo'lishi shart)" value={f.chatId}
            onChange={(e) => setF({ ...f, chatId: e.target.value })} />
        )}
        {f.type === 'INVITE' && (
          <input className={input} type="number" placeholder="Kerakli do'stlar soni" value={f.requiredCount}
            onChange={(e) => setF({ ...f, requiredCount: e.target.value })} />
        )}
        <input className={input} type="number" placeholder="Mukofot (Robux)" value={f.reward} onChange={(e) => setF({ ...f, reward: e.target.value })} />
        <button className={`${btn} bg-[#f3ba2f] text-black`} onClick={() => void add()}>Vazifa qo'shish</button>
        {err && <p className="text-red-400 text-sm md:col-span-2">{err}</p>}
      </div>

      <div className="space-y-2">
        {list.map((t) => (
          <div key={t.id} className={`${card} flex flex-wrap items-center justify-between gap-2 ${t.active ? '' : 'opacity-50'}`}>
            <div>
              <p>{t.title} <span className="text-xs text-[#85827d]">[{t.type}]</span></p>
              <p className="text-xs text-[#85827d] break-all">
                +{fmt(t.reward)} · bajarganlar: {t.completedCount} {t.url ? `· ${t.url}` : ''} {t.chatId ? `· ${t.chatId}` : ''}
              </p>
            </div>
            <div className="flex gap-2">
              <button className={`${btn} bg-[#43433b]`} onClick={async () => { await adminApi.put(`/tasks/${t.id}`, { active: !t.active }); await load(); }}>
                {t.active ? "To'xtatish" : 'Yoqish'}
              </button>
              <button className={`${btn} bg-red-700`} onClick={async () => {
                if (window.confirm("Vazifa o'chirilsinmi?")) { await adminApi.del(`/tasks/${t.id}`); await load(); }
              }}>O'chirish</button>
            </div>
          </div>
        ))}
        {list.length === 0 && <p className="text-[#85827d] text-sm">Vazifalar yo'q</p>}
      </div>
    </div>
  );
};

/* ---------------- Majburiy obuna ---------------- */
interface Channel { id: number; title: string; chatId: string; url: string; active: boolean }
const ChannelsTab: React.FC = () => {
  const [list, setList] = useState<Channel[]>([]);
  const [f, setF] = useState({ title: '', chatId: '', url: '' });
  const [err, setErr] = useState('');
  const load = useCallback(async () => setList(await adminApi.get<Channel[]>('/channels')), []);
  useEffect(() => { void load(); }, [load]);

  const add = async () => {
    setErr('');
    const chatId = f.chatId.trim();
    const url = f.url.trim() || (chatId.startsWith('@') ? `https://t.me/${chatId.slice(1)}` : '');
    try {
      await adminApi.post('/channels', { title: f.title.trim(), chatId, url });
      setF({ title: '', chatId: '', url: '' });
      await load();
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : 'Xatolik');
    }
  };

  return (
    <div className="space-y-4">
      <div className={`${card} grid md:grid-cols-2 gap-3`}>
        <p className="text-xs text-[#85827d] md:col-span-2">
          Foydalanuvchi botda /start bosganda va ilovani ochganda shu kanallarga obuna bo'lishi shart. Botni har bir kanalga <b>admin</b> qilib qo'shing, aks holda tekshirib bo'lmaydi.
        </p>
        <input className={input} placeholder="Nomi (tugmada ko'rinadi)" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
        <input className={input} placeholder="Kanal: @kanal_username yoki -100..." value={f.chatId} onChange={(e) => setF({ ...f, chatId: e.target.value })} />
        <input className={input} placeholder="Havola (bo'sh qoldirsangiz @username dan olinadi)" value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} />
        <button className={`${btn} bg-[#f3ba2f] text-black`} onClick={() => void add()}>Kanal qo'shish</button>
        {err && <p className="text-red-400 text-sm md:col-span-2">{err}</p>}
      </div>
      {list.map((c) => (
        <div key={c.id} className={`${card} flex flex-wrap items-center justify-between gap-2 ${c.active ? '' : 'opacity-50'}`}>
          <div>
            <p>{c.title}</p>
            <p className="text-xs text-[#85827d] break-all">{c.chatId} · {c.url}</p>
          </div>
          <div className="flex gap-2">
            <button className={`${btn} bg-[#43433b]`} onClick={async () => { await adminApi.put(`/channels/${c.id}`, { active: !c.active }); await load(); }}>
              {c.active ? "To'xtatish" : 'Yoqish'}
            </button>
            <button className={`${btn} bg-red-700`} onClick={async () => {
              if (window.confirm("Kanal o'chirilsinmi?")) { await adminApi.del(`/channels/${c.id}`); await load(); }
            }}>O'chirish</button>
          </div>
        </div>
      ))}
      {list.length === 0 && <p className="text-sm text-[#85827d]">Majburiy kanallar yo'q (obuna talab qilinmaydi)</p>}
    </div>
  );
};

/* ---------------- Withdrawals ---------------- */
interface AdminWithdrawal {
  id: number; amount: number; robloxUsername: string; status: 'PENDING' | 'PAID' | 'REJECTED'; createdAt: string;
  user: { firstName: string; username: string | null; telegramId: string };
}
const WithdrawTab: React.FC = () => {
  const [status, setStatus] = useState('PENDING');
  const [list, setList] = useState<AdminWithdrawal[]>([]);
  const load = useCallback(async () => setList(await adminApi.get<AdminWithdrawal[]>(`/withdrawals?status=${status}`)), [status]);
  useEffect(() => { void load(); }, [load]);

  const act = async (id: number, st: 'PAID' | 'REJECTED') => {
    if (st === 'REJECTED' && !window.confirm('Rad etilsa Robux foydalanuvchi balansiga qaytariladi. Davom etasizmi?')) return;
    try {
      await adminApi.patch(`/withdrawals/${id}`, { status: st });
    } catch (e) {
      window.alert(e instanceof ApiError ? e.message : 'Xatolik');
    }
    await load();
  };

  return (
    <div className="space-y-3">
      <select className={input} value={status} onChange={(e) => setStatus(e.target.value)}>
        <option value="PENDING">Kutilayotgan</option>
        <option value="PAID">To'langan</option>
        <option value="REJECTED">Rad etilgan</option>
      </select>
      {list.map((w) => (
        <div key={w.id} className={`${card} flex flex-wrap justify-between gap-2`}>
          <div>
            <p className="text-lg">{fmt(w.amount)} Robux → <b>{w.robloxUsername}</b></p>
            <p className="text-xs text-[#85827d]">
              {w.user.firstName} {w.user.username ? `@${w.user.username}` : ''} · TG {w.user.telegramId} · {new Date(w.createdAt).toLocaleString()}
            </p>
          </div>
          {w.status === 'PENDING' && (
            <div className="flex gap-2 items-start">
              <button className={`${btn} bg-green-700`} onClick={() => void act(w.id, 'PAID')}>To'landi</button>
              <button className={`${btn} bg-red-700`} onClick={() => void act(w.id, 'REJECTED')}>Rad etish</button>
            </div>
          )}
        </div>
      ))}
      {list.length === 0 && <p className="text-sm text-[#85827d]">So'rovlar yo'q</p>}
    </div>
  );
};

/* ---------------- Users ---------------- */
interface AdminUser {
  id: number; telegramId: string; username: string | null; firstName: string; balance: number; totalEarned: number;
  banned: boolean; lastSeenAt: string; _count: { invitees: number };
}
const UsersTab: React.FC = () => {
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState<{ users: AdminUser[]; pages: number; total: number } | null>(null);
  const [edit, setEdit] = useState<{ id: number; value: string } | null>(null);

  const load = useCallback(async () => {
    setData(await adminApi.get<{ users: AdminUser[]; pages: number; total: number }>(`/users?search=${encodeURIComponent(q)}&page=${page}`));
  }, [q, page]);
  useEffect(() => { void load(); }, [load]);

  return (
    <div className="space-y-3">
      <input className={input} placeholder="Qidirish: ID, username yoki ism" value={q}
        onChange={(e) => { setPage(1); setQ(e.target.value); }} />
      <p className="text-xs text-[#85827d]">Jami: {data?.total ?? '...'}</p>
      {data?.users.map((u) => (
        <div key={u.id} className={`${card} ${u.banned ? 'border border-red-700' : ''}`}>
          <div className="flex flex-wrap justify-between gap-2">
            <div>
              <p>{u.firstName} {u.username && <span className="text-[#85827d]">@{u.username}</span>}</p>
              <p className="text-xs text-[#85827d]">
                TG: {u.telegramId} · do'stlar: {u._count.invitees} · jami ishlagan: {fmt(u.totalEarned)} · oxirgi: {new Date(u.lastSeenAt).toLocaleString()}
              </p>
            </div>
            <div className="text-right">
              {edit?.id === u.id ? (
                <div className="flex gap-2">
                  <input className={`${input} w-32`} type="number" value={edit.value} onChange={(e) => setEdit({ id: u.id, value: e.target.value })} />
                  <button className={`${btn} bg-[#f3ba2f] text-black`} onClick={async () => {
                    await adminApi.patch(`/users/${u.id}`, { balance: Number(edit.value) });
                    setEdit(null); await load();
                  }}>OK</button>
                  <button className={`${btn} bg-[#43433b]`} onClick={() => setEdit(null)}>×</button>
                </div>
              ) : (
                <>
                  <p className="text-lg">{fmt(u.balance)}</p>
                  <div className="flex gap-2 mt-1 justify-end">
                    <button className={`${btn} bg-[#43433b]`} onClick={() => setEdit({ id: u.id, value: String(u.balance) })}>Balans</button>
                    <button className={`${btn} ${u.banned ? 'bg-green-700' : 'bg-red-700'}`} onClick={async () => {
                      await adminApi.patch(`/users/${u.id}`, { banned: !u.banned }); await load();
                    }}>{u.banned ? 'Blokdan chiqarish' : 'Bloklash'}</button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      ))}
      <div className="flex items-center gap-3 justify-center">
        <button className={`${btn} bg-[#43433b]`} disabled={page <= 1} onClick={() => setPage(page - 1)}>←</button>
        <span className="text-sm">{page} / {data?.pages ?? 1}</span>
        <button className={`${btn} bg-[#43433b]`} disabled={!data || page >= data.pages} onClick={() => setPage(page + 1)}>→</button>
      </div>
    </div>
  );
};

/* ---------------- Root ---------------- */
const Admin: React.FC = () => {
  const [authed, setAuthed] = useState(!!adminToken.get());
  const [tab, setTab] = useState<Tab>('stats');

  // token eskirsa yoki noto'g'ri bo'lsa kirish oynasiga qaytadi
  useEffect(() => {
    if (!authed) return;
    adminApi.get('/stats').catch((e) => {
      if (e instanceof ApiError && (e.status === 401 || e.status === 403)) {
        adminToken.clear();
        setAuthed(false);
      }
    });
  }, [authed]);

  if (!authed) return <Login onLogin={() => setAuthed(true)} />;

  const tabs: [Tab, string][] = [
    ['stats', 'Statistika'], ['economy', 'Iqtisodiyot'], ['tasks', 'Vazifalar'], ['channels', 'Majburiy obuna'], ['withdraw', 'Yechishlar'], ['users', 'Foydalanuvchilar'],
  ];
  return (
    <div className="min-h-screen bg-black text-white">
      <div className="max-w-4xl mx-auto p-4">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold">Rzon Robux · Admin</h1>
          <button className={`${btn} bg-[#43433b]`} onClick={() => { adminToken.clear(); setAuthed(false); }}>Chiqish</button>
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          {tabs.map(([t, l]) => (
            <button key={t} onClick={() => setTab(t)} className={`${btn} ${tab === t ? 'bg-[#f3ba2f] text-black' : 'bg-[#272a2f]'}`}>{l}</button>
          ))}
        </div>
        {tab === 'stats' && <StatsTab />}
        {tab === 'economy' && <EconomyTab />}
        {tab === 'tasks' && <TasksTab />}
        {tab === 'channels' && <ChannelsTab />}
        {tab === 'withdraw' && <WithdrawTab />}
        {tab === 'users' && <UsersTab />}
      </div>
    </div>
  );
};

export default Admin;
