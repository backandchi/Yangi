import React, { useCallback, useEffect, useState } from 'react';
import './App.css';
import { api, ApiError, Me, tg } from './api';
import { robuxLogo, rzonAvatar } from './images';
import Admin from './admin/Admin';
import Home from './pages/Home';
import Tasks from './pages/Tasks';
import Friends from './pages/Friends';
import Leaderboard from './pages/Leaderboard';
import Withdraw from './pages/Withdraw';

type Tab = 'home' | 'tasks' | 'friends' | 'top' | 'withdraw';

const MiniApp: React.FC = () => {
  const [me, setMe] = useState<Me | null>(null);
  const [balance, setBalance] = useState(0);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<Tab>('home');

  const load = useCallback(async () => {
    try {
      const m = await api.get<Me>('/me');
      setMe(m);
      setBalance(m.balance);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Serverga ulanib bo'lmadi");
    }
  }, []);

  useEffect(() => {
    tg?.ready();
    tg?.expand();
    void load();
  }, [load]);

  if (error) {
    return (
      <div className="h-screen flex items-center justify-center p-6 text-center">
        <p>{error}</p>
      </div>
    );
  }
  if (!me) {
    return <div className="h-screen flex items-center justify-center muted">Yuklanmoqda...</div>;
  }

  const navBtn = (t: Tab, label: string, icon: React.ReactNode) => (
    <button
      onClick={() => setTab(t)}
      className={`text-center flex-1 m-1 py-2 rounded-2xl ${tab === t ? 'gold-gradient text-[#3a2f14]' : 'muted'}`}
    >
      <div className="h-7 flex items-center justify-center text-2xl">{icon}</div>
      <p className="mt-1">{label}</p>
    </button>
  );

  return (
    <div className="flex justify-center select-none">
      <div className="w-full h-screen font-bold flex flex-col max-w-xl overflow-hidden">
        <div style={{ display: tab === 'home' ? 'flex' : 'none' }} className="flex-col flex-grow min-h-0">
          <Home me={me} balance={balance} setBalance={setBalance} />
        </div>
        {tab === 'tasks' && <Tasks balance={balance} setBalance={setBalance} />}
        {tab === 'friends' && <Friends />}
        {tab === 'top' && <Leaderboard />}
        {tab === 'withdraw' && <Withdraw setBalance={setBalance} />}
      </div>

      <div className="fixed bottom-2 left-1/2 transform -translate-x-1/2 w-[calc(100%-1rem)] max-w-xl bg-white border border-[#ebdfbe] shadow-lg flex justify-around items-center z-50 rounded-3xl text-[10px]">
        {navBtn('home', 'Tap', <img src={rzonAvatar} alt="" className="w-7 h-7 rounded-full" />)}
        {navBtn('tasks', 'Vazifa', <img src={robuxLogo} alt="" className="h-7" />)}
        {navBtn('friends', "Do'stlar", '👥')}
        {navBtn('top', 'Reyting', '🏆')}
        {navBtn('withdraw', 'Yechish', '💸')}
      </div>
    </div>
  );
};

const App: React.FC = () => (window.location.pathname.startsWith('/admin') ? <Admin /> : <MiniApp />);

export default App;
