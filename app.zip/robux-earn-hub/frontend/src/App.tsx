import React, { useCallback, useEffect, useState } from 'react';
import './App.css';
import { api, ApiError, Me, tg } from './api';
import Admin from './admin/Admin';
import Home from './pages/Home';
import Tasks from './pages/Tasks';
import Friends from './pages/Friends';
import Hamster from './icons/Hamster';
import FriendsIcon from './icons/Friends';
import Coins from './icons/Coins';

type Tab = 'home' | 'tasks' | 'friends';

const MiniApp: React.FC = () => {
  const [me, setMe] = useState<Me | null>(null);
  const [balance, setBalance] = useState(0);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<Tab>('home');

  const load = useCallback(async () => {
    try {
      const m = await api.get<Me>('/me');
      setMe(m);
      setBalance(m.balance);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Serverga ulanib bo\'lmadi');
    }
  }, []);

  useEffect(() => {
    tg?.ready();
    tg?.expand();
    void load();
  }, [load]);

  if (error) {
    return (
      <div className="bg-black text-white h-screen flex items-center justify-center p-6 text-center">
        <p>{error}</p>
      </div>
    );
  }
  if (!me) {
    return <div className="bg-black text-white h-screen flex items-center justify-center">Yuklanmoqda...</div>;
  }

  const navBtn = (t: Tab, label: string, icon: React.ReactNode) => (
    <button
      onClick={() => setTab(t)}
      className={`text-center w-1/3 m-1 p-2 rounded-2xl ${tab === t ? 'bg-[#1c1f24] text-white' : 'text-[#85827d]'}`}
    >
      {icon}
      <p className="mt-1">{label}</p>
    </button>
  );

  return (
    <div className="bg-black flex justify-center select-none">
      <div className="w-full bg-black text-white h-screen font-bold flex flex-col max-w-xl overflow-hidden">
        <div style={{ display: tab === 'home' ? 'flex' : 'none' }} className="flex-col flex-grow min-h-0">
          <Home me={me} balance={balance} setBalance={setBalance} />
        </div>
        {tab === 'tasks' && <Tasks balance={balance} setBalance={setBalance} />}
        {tab === 'friends' && <Friends />}
      </div>

      <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-[calc(100%-2rem)] max-w-xl bg-[#272a2f] flex justify-around items-center z-50 rounded-3xl text-xs">
        {navBtn('home', 'Tap', <Hamster size={32} className="mx-auto" />)}
        {navBtn('tasks', 'Vazifalar', <Coins size={32} className="mx-auto" />)}
        {navBtn('friends', 'Do\'stlar', <FriendsIcon size={32} className="mx-auto" />)}
      </div>
      {me.isAdmin && (
        <a href="/admin" className="fixed top-2 right-2 z-50 text-[10px] bg-[#272a2f] text-white rounded px-2 py-1">
          Admin
        </a>
      )}
    </div>
  );
};

const App: React.FC = () =>
  window.location.pathname.startsWith('/admin') ? <Admin /> : <MiniApp />;

export default App;
