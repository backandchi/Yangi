export const tg = window.Telegram?.WebApp;

export interface GateChannel {
  title: string;
  url: string;
}

export class ApiError extends Error {
  status: number;
  code?: string;
  channels?: GateChannel[];
  constructor(message: string, status: number, code?: string, channels?: GateChannel[]) {
    super(message);
    this.status = status;
    this.code = code;
    this.channels = channels;
  }
}

async function request<T>(path: string, method: string, auth: string, body?: unknown): Promise<T> {
  const res = await fetch(`/api${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(auth ? { Authorization: auth } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const d = data as { error?: string; code?: string; channels?: GateChannel[] };
    // ilova ochiq paytda obuna bekor qilingan bo'lsa: qayta yuklab, obuna ekranini ko'rsatamiz
    if (d.code === 'SUBSCRIBE_REQUIRED' && path !== '/me') window.location.reload();
    throw new ApiError(d.error || `Xato (${res.status})`, res.status, d.code, d.channels);
  }
  return data as T;
}

function userAuth(): string {
  if (tg?.initData) return `tma ${tg.initData}`;
  if (import.meta.env.DEV) return 'dev 1:DevUser'; // faqat lokal sinov uchun (server DEV_AUTH=true bo'lsa)
  return '';
}

export const api = {
  get: <T,>(p: string) => request<T>(p, 'GET', userAuth()),
  post: <T,>(p: string, b?: unknown) => request<T>(p, 'POST', userAuth(), b ?? {}),
};

/* ---- Admin ---- */
const TOKEN_KEY = 'admin_token';
export const adminToken = {
  get: () => sessionStorage.getItem(TOKEN_KEY) || '',
  set: (t: string) => sessionStorage.setItem(TOKEN_KEY, t),
  clear: () => sessionStorage.removeItem(TOKEN_KEY),
};
const adminAuth = () => `Bearer ${adminToken.get()}`;

export const adminApi = {
  loginTelegram: (initData: string) => request<{ token: string }>('/admin/login-telegram', 'POST', '', { initData }),
  get: <T,>(p: string) => request<T>(`/admin${p}`, 'GET', adminAuth()),
  post: <T,>(p: string, b: unknown) => request<T>(`/admin${p}`, 'POST', adminAuth(), b),
  put: <T,>(p: string, b: unknown) => request<T>(`/admin${p}`, 'PUT', adminAuth(), b),
  patch: <T,>(p: string, b: unknown) => request<T>(`/admin${p}`, 'PATCH', adminAuth(), b),
  del: <T,>(p: string) => request<T>(`/admin${p}`, 'DELETE', adminAuth()),
};

/* ---- Turlar ---- */
export interface Me {
  id: number;
  telegramId: string;
  firstName: string;
  username: string | null;
  balance: number;
  totalEarned: number;
  energy: number;
  dailyEarned: number;
  dailyTaps: number;
  referralLink: string;
  settings: {
    perTap: number;
    maxEnergy: number;
    energyRegenPerSec: number;
    energyPerTap: number;
    dailyLimit: number;
    dailyTapLimit: number;
    referralReward: number;
    referredReward: number;
  };
}

export interface TaskItem {
  id: number;
  title: string;
  url: string | null;
  type: 'YOUTUBE' | 'TELEGRAM' | 'INVITE';
  reward: number;
  requiredCount: number;
  progress?: number;
  started: boolean;
  completed: boolean;
}

export interface FriendsRes {
  count: number;
  link: string;
  referralReward: number;
  referredReward: number;
  blocked: number;
  fraudPenalty: number;
  friends: { firstName: string; username: string | null; createdAt: string; fraud: boolean; welcomed: boolean }[];
}

export const fmt = (n: number) => (Math.round(n * 100) / 100).toLocaleString();

export function openUrl(url: string) {
  if (/^https?:\/\/t\.me\//.test(url) && tg?.openTelegramLink) tg.openTelegramLink(url);
  else if (tg?.openLink) tg.openLink(url);
  else window.open(url, '_blank');
}

export interface LeaderboardRes {
  top: { rank: number; name: string; username: string | null; count: number; isMe: boolean }[];
  myCount: number;
}

export interface WithdrawInfo {
  balance: number;
  totalEarned: number;
  minWithdraw: number;
  open: boolean;
  reason: string;
  openAt: string | null;
  history: { id: number; amount: number; robloxUsername: string; status: 'PENDING' | 'PAID' | 'REJECTED'; createdAt: string }[];
}
