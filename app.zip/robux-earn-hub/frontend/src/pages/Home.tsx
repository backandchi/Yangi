import React, { useCallback, useEffect, useRef, useState } from 'react';
import { api, fmt, Me, tg } from '../api';
import { robuxLogo, rzonAvatar } from '../images';

interface TapRes {
  accepted: number;
  balance: number;
  energy: number;
  dailyEarned: number;
  dailyTaps: number;
}

const levelNames = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Epic', 'Legendary', 'Master', 'GrandMaster', 'Lord'];
const levelMin = [0, 1000, 5000, 20000, 100000, 500000, 2000000, 10000000, 50000000, 200000000];

interface Props {
  me: Me;
  balance: number;
  setBalance: React.Dispatch<React.SetStateAction<number>>;
}

const Home: React.FC<Props> = ({ me, balance, setBalance }) => {
  const st = me.settings;
  const [energy, setEnergy] = useState(me.energy);
  const [clicks, setClicks] = useState<{ id: number; x: number; y: number }[]>([]);
  const [tapsView, setTapsView] = useState(me.dailyTaps);
  const energyRef = useRef(me.energy);
  const dailyRef = useRef(me.dailyEarned);
  const tapsRef = useRef(me.dailyTaps);
  const pending = useRef(0);
  const inflight = useRef(false);
  const idRef = useRef(0);

  const flush = useCallback(async () => {
    if (inflight.current || pending.current === 0) return;
    const n = Math.min(pending.current, 500);
    pending.current -= n;
    inflight.current = true;
    try {
      const r = await api.post<TapRes>('/tap', { count: n });
      // server qiymati + hali yuborilmagan kliklar
      const p = pending.current;
      setBalance(r.balance + p * st.perTap);
      energyRef.current = Math.max(0, r.energy - p * st.energyPerTap);
      dailyRef.current = r.dailyEarned + p * st.perTap;
      tapsRef.current = r.dailyTaps + p;
      setEnergy(energyRef.current);
      setTapsView(tapsRef.current);
    } catch {
      pending.current += n;
    } finally {
      inflight.current = false;
    }
  }, [setBalance, st.perTap, st.energyPerTap]);

  useEffect(() => {
    const flushTimer = setInterval(() => void flush(), 1500);
    const regenTimer = setInterval(() => {
      energyRef.current = Math.min(st.maxEnergy, energyRef.current + st.energyRegenPerSec * 0.25);
      setEnergy(energyRef.current);
    }, 250);
    const onHide = () => {
      if (document.visibilityState === 'hidden') void flush();
    };
    document.addEventListener('visibilitychange', onHide);
    return () => {
      clearInterval(flushTimer);
      clearInterval(regenTimer);
      document.removeEventListener('visibilitychange', onHide);
    };
  }, [flush, st.maxEnergy, st.energyRegenPerSec]);

  const limitReached = tapsView >= st.dailyTapLimit || dailyRef.current + st.perTap > st.dailyLimit + 1e-9;

  const handleTap = (e: React.PointerEvent<HTMLDivElement>) => {
    if (energyRef.current < st.energyPerTap) return;
    if (tapsRef.current >= st.dailyTapLimit) return;
    if (dailyRef.current + st.perTap > st.dailyLimit + 1e-9) return;

    energyRef.current -= st.energyPerTap;
    dailyRef.current += st.perTap;
    tapsRef.current += 1;
    pending.current += 1;
    setEnergy(energyRef.current);
    setTapsView(tapsRef.current);
    setBalance((b) => b + st.perTap);
    tg?.HapticFeedback?.impactOccurred('light');

    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    card.style.transform = `perspective(1000px) rotateX(${-y / 10}deg) rotateY(${x / 10}deg)`;
    setTimeout(() => (card.style.transform = ''), 100);

    const id = ++idRef.current;
    setClicks((c) => [...c.slice(-15), { id, x: e.clientX, y: e.clientY }]);
  };

  let levelIndex = 0;
  levelMin.forEach((m, i) => {
    if (balance >= m) levelIndex = i;
  });
  const next = levelMin[levelIndex + 1];
  const progress = next ? Math.min(100, ((balance - levelMin[levelIndex]) / (next - levelMin[levelIndex])) * 100) : 100;

  return (
    <>
      <div className="px-4 z-10">
        <div className="flex items-center justify-between pt-4">
          <p className="text-sm">{me.firstName}</p>
          <p className="text-xs muted">Bugun: {fmt(tapsView)} / {fmt(st.dailyTapLimit)} bosish</p>
        </div>
        <div className="mt-2">
          <div className="flex justify-between">
            <p className="text-sm">{levelNames[levelIndex]}</p>
            <p className="text-sm">{levelIndex + 1} <span className="muted">/ {levelNames.length}</span></p>
          </div>
          <div className="mt-1 border-2 border-[#ebdfbe] rounded-full bg-white">
            <div className="w-full h-2 rounded-full">
              <div className="progress-gradient h-2 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-grow mt-4 gold-gradient rounded-t-[48px] relative top-glow z-0 min-h-0">
        <div className="absolute top-[2px] left-0 right-0 bottom-0 bg-[#fffdf6] rounded-t-[46px] overflow-hidden">
          <div className="px-4 mt-5 flex justify-center">
            <div className="px-4 py-1 flex items-center space-x-2">
              <img src={robuxLogo} alt="Robux" className="h-10" />
              <p className="text-4xl">{fmt(balance)}</p>
            </div>
          </div>
          <p className="text-center text-xs muted -mt-1">Robux</p>

          <div className="px-4 mt-3 flex justify-center">
            <div
              className="p-3 rounded-full circle-outer"
              style={{ touchAction: 'manipulation' }}
              onPointerDown={handleTap}
            >
              <div className="w-full h-full rounded-full circle-inner">
                <img src={rzonAvatar} alt="Tap" className="w-full h-full object-cover pointer-events-none" draggable={false} />
              </div>
            </div>
          </div>

          <div className="px-6 mt-4">
            <div className="flex justify-between text-sm">
              <span>⚡ {Math.floor(energy)} / {st.maxEnergy}</span>
              {limitReached && <span className="text-[#a9935a]">Kunlik limit tugadi</span>}
            </div>
            <div className="mt-1 h-3 bg-[#f4ecd3] rounded-full">
              <div className="h-3 rounded-full progress-gradient" style={{ width: `${(energy / st.maxEnergy) * 100}%` }}></div>
            </div>
          </div>
        </div>
      </div>

      {clicks.map((c) => (
        <div
          key={c.id}
          className="fixed text-4xl font-bold opacity-0 text-[#a9935a] pointer-events-none z-50"
          style={{ top: `${c.y - 42}px`, left: `${c.x - 20}px`, animation: 'float 1s ease-out' }}
          onAnimationEnd={() => setClicks((cs) => cs.filter((x) => x.id !== c.id))}
        >
          +{fmt(st.perTap)}
        </div>
      ))}
    </>
  );
};

export default Home;
