import React, { useCallback, useEffect, useRef, useState } from 'react';
import { api, fmt, Me, tg } from '../api';
import { dollarCoin, mainCharacter } from '../images';

interface TapRes {
  accepted: number;
  balance: number;
  energy: number;
  dailyEarned: number;
}

const levelNames = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Epic', 'Legendary', 'Master', 'GrandMaster', 'Lord'];
const levelMin = [0, 1000, 5000, 20000, 100000, 500000, 2000000, 10000000, 50000000, 200000000];

interface Props {
  me: Me;
  balance: number;
  setBalance: React.Dispatch<React.SetStateAction<number>>;
}

const Home: React.FC<Props> = ({ me, balance, setBalance }) => {
  const st = me.settings;
  const [energy, setEnergy] = useState(me.energy);
  const [clicks, setClicks] = useState<{ id: number; x: number; y: number }[]>([]);
  const [dailyView, setDailyView] = useState(me.dailyEarned);
  const energyRef = useRef(me.energy);
  const dailyRef = useRef(me.dailyEarned);
  const pending = useRef(0);
  const inflight = useRef(false);
  const idRef = useRef(0);

  const flush = useCallback(async () => {
    if (inflight.current || pending.current === 0) return;
    const n = Math.min(pending.current, 500);
    pending.current -= n;
    inflight.current = true;
    try {
      const r = await api.post<TapRes>('/tap', { count: n });
      // server qiymati + hali yuborilmagan kliklar
      const p = pending.current;
      setBalance(r.balance + p * st.perTap);
      energyRef.current = Math.max(0, r.energy - p * st.energyPerTap);
      dailyRef.current = r.dailyEarned + p * st.perTap;
      setEnergy(energyRef.current);
      setDailyView(dailyRef.current);
    } catch {
      pending.current += n;
    } finally {
      inflight.current = false;
    }
  }, [setBalance, st.perTap, st.energyPerTap]);

  useEffect(() => {
    const flushTimer = setInterval(() => void flush(), 1500);
    const regenTimer = setInterval(() => {
      energyRef.current = Math.min(st.maxEnergy, energyRef.current + st.energyRegenPerSec * 0.25);
      setEnergy(energyRef.current);
    }, 250);
    const onHide = () => {
      if (document.visibilityState === 'hidden') void flush();
    };
    document.addEventListener('visibilitychange', onHide);
    return () => {
      clearInterval(flushTimer);
      clearInterval(regenTimer);
      document.removeEventListener('visibilitychange', onHide);
    };
  }, [flush, st.maxEnergy, st.energyRegenPerSec]);

  const handleTap = (e: React.PointerEvent<HTMLDivElement>) => {
    if (energyRef.current < st.energyPerTap) return;
    if (dailyRef.current + st.perTap > st.dailyLimit + 1e-9) return;

    energyRef.current -= st.energyPerTap;
    dailyRef.current += st.perTap;
    pending.current += 1;
    setEnergy(energyRef.current);
    setDailyView(dailyRef.current);
    setBalance((b) => b + st.perTap);
    tg?.HapticFeedback?.impactOccurred('light');

    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    card.style.transform = `perspective(1000px) rotateX(${-y / 10}deg) rotateY(${x / 10}deg)`;
    setTimeout(() => (card.style.transform = ''), 100);

    const id = ++idRef.current;
    setClicks((c) => [...c.slice(-15), { id, x: e.clientX, y: e.clientY }]);
  };

  let levelIndex = 0;
  levelMin.forEach((m, i) => {
    if (balance >= m) levelIndex = i;
  });
  const next = levelMin[levelIndex + 1];
  const progress = next ? Math.min(100, ((balance - levelMin[levelIndex]) / (next - levelMin[levelIndex])) * 100) : 100;
  const dailyLeft = Math.max(0, st.dailyLimit - dailyView);

  return (
    <>
      <div className="px-4 z-10">
        <div className="flex items-center justify-between pt-4">
          <p className="text-sm">{me.firstName}</p>
          <p className="text-xs text-[#95908a]">Bugun: {fmt(dailyView)} / {fmt(st.dailyLimit)}</p>
        </div>
        <div className="mt-2">
          <div className="flex justify-between">
            <p className="text-sm">{levelNames[levelIndex]}</p>
            <p className="text-sm">{levelIndex + 1} <span className="text-[#95908a]">/ {levelNames.length}</span></p>
          </div>
          <div className="mt-1 border-2 border-[#43433b] rounded-full">
            <div className="w-full h-2 bg-[#43433b]/[0.6] rounded-full">
              <div className="progress-gradient h-2 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-grow mt-4 bg-[#f3ba2f] rounded-t-[48px] relative top-glow z-0 min-h-0">
        <div className="absolute top-[2px] left-0 right-0 bottom-0 bg-[#1d2025] rounded-t-[46px] overflow-hidden">
          <div className="px-4 mt-6 flex justify-center">
            <div className="px-4 py-2 flex items-center space-x-2">
              <img src={dollarCoin} alt="Robux" className="w-10 h-10" />
              <p className="text-4xl text-white">{fmt(balance)}</p>
            </div>
          </div>
          <p className="text-center text-xs text-[#85827d] -mt-1">Robux ball</p>

          <div className="px-4 mt-4 flex justify-center">
            <div
              className="w-80 h-80 p-4 rounded-full circle-outer"
              style={{ touchAction: 'manipulation' }}
              onPointerDown={handleTap}
            >
              <div className="w-full h-full rounded-full circle-inner">
                <img src={mainCharacter} alt="Tap" className="w-full h-full pointer-events-none" draggable={false} />
              </div>
            </div>
          </div>

          <div className="px-6 mt-4">
            <div className="flex justify-between text-sm">
              <span>⚡ {Math.floor(energy)} / {st.maxEnergy}</span>
              {dailyLeft <= 0 && <span className="text-[#f3ba2f]">Kunlik limit tugadi</span>}
            </div>
            <div className="mt-1 h-3 bg-[#43433b]/[0.6] rounded-full">
              <div className="h-3 rounded-full progress-gradient" style={{ width: `${(energy / st.maxEnergy) * 100}%` }}></div>
            </div>
          </div>
        </div>
      </div>

      {clicks.map((c) => (
        <div
          key={c.id}
          className="fixed text-4xl font-bold opacity-0 text-white pointer-events-none z-50"
          style={{ top: `${c.y - 42}px`, left: `${c.x - 20}px`, animation: 'float 1s ease-out' }}
          onAnimationEnd={() => setClicks((cs) => cs.filter((x) => x.id !== c.id))}
        >
          +{fmt(st.perTap)}
        </div>
      ))}
    </>
  );
};

export default Home;
