import React, { useCallback, useEffect, useState } from 'react';
import { api, ApiError, fmt, openUrl, TaskItem } from '../api';
import { dollarCoin } from '../images';

interface Props {
  balance: number;
  setBalance: React.Dispatch<React.SetStateAction<number>>;
}

const typeLabel: Record<TaskItem['type'], string> = {
  YOUTUBE: '▶️ YouTube video',
  TELEGRAM: '📣 Telegram kanal',
  INVITE: '👥 Do\'st taklif qilish',
};

const Tasks: React.FC<Props> = ({ balance, setBalance }) => {
  const [tasks, setTasks] = useState<TaskItem[] | null>(null);
  const [busy, setBusy] = useState<number | null>(null);
  const [msg, setMsg] = useState<{ id: number; text: string; ok: boolean } | null>(null);

  const load = useCallback(async () => {
    try {
      setTasks(await api.get<TaskItem[]>('/tasks'));
    } catch {
      setTasks([]);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  const start = async (t: TaskItem) => {
    if (t.url) openUrl(t.url);
    try {
      await api.post(`/tasks/${t.id}/start`);
      setTasks((ts) => ts && ts.map((x) => (x.id === t.id ? { ...x, started: true } : x)));
    } catch {
      /* e'tiborsiz */
    }
  };

  const claim = async (t: TaskItem) => {
    setBusy(t.id);
    setMsg(null);
    try {
      const r = await api.post<{ reward: number; balance: number }>(`/tasks/${t.id}/claim`);
      setBalance(r.balance);
      setTasks((ts) => ts && ts.map((x) => (x.id === t.id ? { ...x, completed: true } : x)));
      setMsg({ id: t.id, text: `+${fmt(r.reward)} ball qo'shildi!`, ok: true });
    } catch (e) {
      setMsg({ id: t.id, text: e instanceof ApiError ? e.message : 'Xatolik', ok: false });
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="flex-grow overflow-y-auto px-4 pt-6 pb-28">
      <div className="flex items-center justify-center space-x-2">
        <img src={dollarCoin} alt="" className="w-8 h-8" />
        <p className="text-3xl">{fmt(balance)}</p>
      </div>
      <h2 className="text-xl mt-4 mb-3">Vazifalar</h2>

      {tasks === null && <p className="text-[#85827d]">Yuklanmoqda...</p>}
      {tasks && tasks.length === 0 && <p className="text-[#85827d]">Hozircha vazifalar yo'q</p>}

      <div className="space-y-3">
        {tasks?.map((t) => (
          <div key={t.id} className="bg-[#272a2f] rounded-2xl p-4">
            <div className="flex justify-between items-start gap-2">
              <div>
                <p className="text-xs text-[#85827d]">{typeLabel[t.type]}</p>
                <p className="mt-1">{t.title}</p>
                <p className="text-sm text-[#f3ba2f] mt-1">+{fmt(t.reward)}</p>
                {t.type === 'INVITE' && (
                  <p className="text-xs text-[#85827d] mt-1">{t.progress ?? 0} / {t.requiredCount} do'st</p>
                )}
              </div>
              <div className="shrink-0">
                {t.completed ? (
                  <span className="text-green-400 text-sm">✓ Bajarildi</span>
                ) : t.type !== 'INVITE' && !t.started ? (
                  <button onClick={() => void start(t)} className="bg-[#f3ba2f] text-black rounded-full px-4 py-2 text-sm">
                    Boshlash
                  </button>
                ) : (
                  <button
                    disabled={busy === t.id}
                    onClick={() => void claim(t)}
                    className="bg-[#5a60f0] text-white rounded-full px-4 py-2 text-sm disabled:opacity-50"
                  >
                    {busy === t.id ? '...' : 'Tekshirish'}
                  </button>
                )}
              </div>
            </div>
            {t.type !== 'INVITE' && t.started && !t.completed && t.url && (
              <button onClick={() => openUrl(t.url!)} className="text-xs text-[#85827d] underline mt-2">
                Havolani qayta ochish
              </button>
            )}
            {msg?.id === t.id && (
              <p className={`text-xs mt-2 ${msg.ok ? 'text-green-400' : 'text-red-400'}`}>{msg.text}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Tasks;
