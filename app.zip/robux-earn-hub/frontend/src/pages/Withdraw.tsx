import React, { useCallback, useEffect, useState } from 'react';
import { api, ApiError, fmt, WithdrawInfo } from '../api';
import { robuxLogo } from '../images';

interface Props {
  setBalance: React.Dispatch<React.SetStateAction<number>>;
}

const statusLabel = { PENDING: '⏳ Kutilmoqda', PAID: "✅ To'langan", REJECTED: '❌ Rad etilgan' } as const;

const Withdraw: React.FC<Props> = ({ setBalance }) => {
  const [info, setInfo] = useState<WithdrawInfo | null>(null);
  const [username, setUsername] = useState('');
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);

  const load = useCallback(async () => {
    try {
      const i = await api.get<WithdrawInfo>('/withdraw');
      setInfo(i);
      setAmount((a) => a || String(Math.floor(i.balance)));
    } catch {
      /* e'tiborsiz */
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  const submit = async () => {
    setBusy(true);
    setMsg(null);
    try {
      const r = await api.post<{ balance: number }>('/withdraw', { amount: Number(amount), robloxUsername: username.trim() });
      setBalance(r.balance);
      setMsg({ text: "So'rov yuborildi! Admin tekshirib, Robux ni yuboradi.", ok: true });
      setAmount('');
      await load();
    } catch (e) {
      setMsg({ text: e instanceof ApiError ? e.message : 'Xatolik', ok: false });
    } finally {
      setBusy(false);
    }
  };

  if (!info) return <div className="flex-grow p-6 muted">Yuklanmoqda...</div>;

  const enough = info.balance >= info.minWithdraw;
  return (
    <div className="flex-grow overflow-y-auto px-4 pt-6 pb-28">
      <h2 className="text-xl">💸 Robux yechib olish</h2>

      <div className="grid grid-cols-2 gap-3 mt-4">
        <div className="card p-3">
          <p className="text-xs muted">Balans</p>
          <p className="text-xl mt-1 flex items-center gap-1"><img src={robuxLogo} alt="" className="h-5" />{fmt(info.balance)}</p>
        </div>
        <div className="card p-3">
          <p className="text-xs muted">Jami ishlangan</p>
          <p className="text-xl mt-1 flex items-center gap-1"><img src={robuxLogo} alt="" className="h-5" />{fmt(info.totalEarned)}</p>
        </div>
      </div>
      <p className="text-xs muted mt-2">Minimal yechish: {fmt(info.minWithdraw)} Robux</p>

      {!info.open ? (
        <div className="card p-4 mt-4 text-sm">
          🔒 {info.reason}
          {info.openAt && <p className="muted mt-1">Ochilish sanasi: {new Date(info.openAt).toLocaleString()}</p>}
        </div>
      ) : (
        <div className="card p-4 mt-4 space-y-3">
          <label className="text-xs muted block">
            Roblox username
            <input className="field mt-1" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="masalan: Rzon_Play" autoCapitalize="off" />
          </label>
          <label className="text-xs muted block">
            Miqdor (Robux)
            <input className="field mt-1" type="number" inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </label>
          <button className="btn-gold w-full py-3" disabled={busy || !enough || !username.trim() || !Number(amount)} onClick={() => void submit()}>
            {busy ? '...' : 'Yechib olish'}
          </button>
          {!enough && <p className="text-xs muted">Yechish uchun kamida {fmt(info.minWithdraw)} Robux kerak.</p>}
        </div>
      )}
      {msg && <p className={`text-sm mt-3 ${msg.ok ? 'text-green-600' : 'text-red-600'}`}>{msg.text}</p>}

      <h3 className="mt-6 mb-2">Tarix</h3>
      {info.history.length === 0 && <p className="text-sm muted">So'rovlar yo'q</p>}
      <div className="space-y-2">
        {info.history.map((h) => (
          <div key={h.id} className="card px-4 py-2 flex justify-between text-sm">
            <span>{fmt(h.amount)} → {h.robloxUsername}</span>
            <span className="muted">{statusLabel[h.status]}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Withdraw;
