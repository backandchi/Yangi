import React, { useEffect, useState } from 'react';
import { api, LeaderboardRes } from '../api';

const medal = (r: number) => (r === 1 ? '🥇' : r === 2 ? '🥈' : r === 3 ? '🥉' : String(r));

const Leaderboard: React.FC = () => {
  const [data, setData] = useState<LeaderboardRes | null>(null);

  useEffect(() => {
    api.get<LeaderboardRes>('/leaderboard').then(setData).catch(() => undefined);
  }, []);

  if (!data) return <div className="flex-grow p-6 muted">Yuklanmoqda...</div>;

  return (
    <div className="flex-grow overflow-y-auto px-4 pt-6 pb-28">
      <h2 className="text-xl">🏆 Eng yaxshi 50 ta</h2>
      <p className="text-sm muted mt-1">Eng ko'p do'st taklif qilganlar. Sizda: {data.myCount} ta do'st</p>

      {data.top.length === 0 && <p className="text-sm muted mt-4">Hozircha reyting bo'sh</p>}
      <div className="space-y-2 mt-4">
        {data.top.map((u) => (
          <div key={u.rank} className={`card px-4 py-3 flex items-center justify-between text-sm ${u.isMe ? 'border-[#c9b070] bg-[#fffaf0]' : ''}`}>
            <div className="flex items-center gap-3">
              <span className="w-8 text-center text-lg">{medal(u.rank)}</span>
              <span>{u.name}{u.username ? <span className="muted"> @{u.username}</span> : null}</span>
            </div>
            <span className="text-[#a9935a]">{u.count} 👥</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Leaderboard;
