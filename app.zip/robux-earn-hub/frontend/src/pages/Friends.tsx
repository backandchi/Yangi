import React, { useEffect, useState } from 'react';
import { api, FriendsRes, fmt, openUrl } from '../api';

const Friends: React.FC = () => {
  const [data, setData] = useState<FriendsRes | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    api.get<FriendsRes>('/friends').then(setData).catch(() => undefined);
  }, []);

  const copy = async () => {
    if (!data?.link) return;
    try {
      await navigator.clipboard.writeText(data.link);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard mavjud emas */
    }
  };

  const share = () => {
    if (!data?.link) return;
    const text = 'Robux Earn Hub da tap qilib Robux ballari ishla! 🎮';
    openUrl(`https://t.me/share/url?url=${encodeURIComponent(data.link)}&text=${encodeURIComponent(text)}`);
  };

  if (!data) return <div className="flex-grow p-6 text-[#85827d]">Yuklanmoqda...</div>;

  return (
    <div className="flex-grow overflow-y-auto px-4 pt-6 pb-28">
      <h2 className="text-xl">Do'stlarni taklif qiling</h2>
      <p className="text-sm text-[#85827d] mt-2">
        Siz +{fmt(data.referralReward)}, do'stingiz +{fmt(data.referredReward)} ball oladi.
      </p>

      <div className="bg-[#272a2f] rounded-2xl p-4 mt-4">
        <p className="text-xs text-[#85827d]">Sizning havolangiz</p>
        <p className="text-sm break-all mt-1">{data.link || 'BOT_USERNAME sozlanmagan'}</p>
        <div className="flex gap-2 mt-3">
          <button onClick={share} className="flex-1 bg-[#f3ba2f] text-black rounded-full py-2 text-sm">Ulashish</button>
          <button onClick={() => void copy()} className="flex-1 bg-[#43433b] rounded-full py-2 text-sm">
            {copied ? 'Nusxalandi ✓' : 'Nusxalash'}
          </button>
        </div>
      </div>

      <h3 className="mt-6 mb-2">Do'stlar ({data.count})</h3>
      {data.friends.length === 0 && <p className="text-sm text-[#85827d]">Hali hech kim taklif qilinmagan</p>}
      <div className="space-y-2">
        {data.friends.map((f, i) => (
          <div key={i} className="bg-[#272a2f] rounded-xl px-4 py-2 flex justify-between text-sm">
            <span>{f.firstName}</span>
            <span className="text-[#85827d]">{f.username ? `@${f.username}` : ''}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Friends;
