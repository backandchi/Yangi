import React, { useEffect, useState } from 'react';
import { api, FriendsRes, fmt, openUrl } from '../api';

const Friends: React.FC = () => {
  const [data, setData] = useState<FriendsRes | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    api.get<FriendsRes>('/friends').then(setData).catch(() => undefined);
  }, []);

  const copy = async () => {
    if (!data?.link) return;
    try {
      await navigator.clipboard.writeText(data.link);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard mavjud emas */
    }
  };

  const share = () => {
    if (!data?.link) return;
    const text = 'Rzon Robux ilovasida tap qilib Robux ishla! 🎮';
    openUrl(`https://t.me/share/url?url=${encodeURIComponent(data.link)}&text=${encodeURIComponent(text)}`);
  };

  if (!data) return <div className="flex-grow p-6 muted">Yuklanmoqda...</div>;

  return (
    <div className="flex-grow overflow-y-auto px-4 pt-6 pb-28">
      <h2 className="text-xl">Do'stlarni taklif qiling</h2>
      <p className="text-sm muted mt-2">
        Siz +{fmt(data.referralReward)} Robux, do'stingiz +{fmt(data.referredReward)} Robux oladi.
      </p>
      <p className="text-xs muted mt-1">
        Bir qurilma/IP dan takroriy referal hisobga olinmaydi, bonus berilmaydi va sizdan {fmt(data.fraudPenalty)} Robux ushlanadi.
      </p>

      <div className="card p-4 mt-4">
        <p className="text-xs muted">Sizning havolangiz</p>
        <p className="text-sm break-all mt-1">{data.link || 'BOT_USERNAME sozlanmagan'}</p>
        <div className="flex gap-2 mt-3">
          <button onClick={share} className="flex-1 btn-gold py-2 text-sm">Ulashish</button>
          <button onClick={() => void copy()} className="flex-1 btn-soft py-2 text-sm">
            {copied ? 'Nusxalandi ✓' : 'Nusxalash'}
          </button>
        </div>
      </div>

      <h3 className="mt-6 mb-2">Do'stlar ({data.count}){data.blocked > 0 && <span className="text-red-600"> · bloklangan: {data.blocked}</span>}</h3>
      {data.friends.length === 0 && <p className="text-sm muted">Hali hech kim taklif qilinmagan</p>}
      <div className="space-y-2">
        {data.friends.map((f, i) => (
          <div
            key={i}
            className={`px-4 py-2 rounded-2xl text-sm border ${f.fraud ? 'bg-red-50 border-red-300' : 'card'}`}
          >
            <div className="flex justify-between">
              <span className={f.fraud ? 'text-red-700' : ''}>{f.firstName}</span>
              <span className="muted">{f.username ? `@${f.username}` : ''}</span>
            </div>
            {f.fraud ? (
              <p className="text-xs text-red-600 mt-1">⚠️ Bitta qurilmadan foydalandingiz: bonus berilmadi, Robux ushlab qolindi</p>
            ) : f.welcomed ? (
              <p className="text-xs text-green-600 mt-1">✓ +{fmt(data.referralReward)} Robux berildi</p>
            ) : (
              <p className="text-xs muted mt-1">⏳ Hali ilovani ochmagan</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Friends;
